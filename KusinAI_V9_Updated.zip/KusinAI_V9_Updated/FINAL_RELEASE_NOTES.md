# KusinA.I. V9 — revised release notes

## Implemented in this project copy

- Consistent indigo/plum/coral/ivory UI with readable typography, common navigation, compact cards, responsive layouts, bounded scroll areas, and no green theme.
- Home page includes the introduction, module links, and a live searchable ingredient-record section; the add/edit form remains on the Ingredients page.
- Shared Philippine date/time and AI Analysis entry point appear on every module page.
- Ingredient Library uses a searchable, filterable database-backed table; the Recipe Builder ingredient picker uses selectable ingredient cards. The ingredient checkbox is small and aligned next to its text.
- Recipe input is explicitly per serving; calculation derives batch quantities. Cost breakdowns include an explicit line count and per-serving/batch/purchase quantities. Cost Predictor now includes visual ingredient-cost bars, batch-versus-serving comparison, and optional budget-versus-estimate comparison.
- Decimal-backed peso arithmetic, compatible-unit conversions, package-price normalization, and guards against unsupported mass/volume/piece conversions.
- Ratings include a practical 1–5 preparation difficulty score and a visible rationale.
- Undocumented yield-loss values no longer inflate purchases; a source is required for non-zero yield loss.
- Saves replaces Favorites in navigation; the old `/favorites` route redirects to `/saves`.
- Bundled price references updated to 23 explicitly mapped observations from the DA Daily Price Index dated 13 November 2026, NCR scope, with separate oil variants and no guessed prices for unlisted items.
- Gemini Flash uses the server-side Gemini Developer API; Firebase, App Check, and reCAPTCHA are not used.
- Mac launcher, `.env.example`, lean runtime requirements, VS Code run/debug tasks, and setup instructions.

## AI setup

Create a Gemini API key in Google AI Studio and place it in `GEMINI_API_KEY` inside the local `.env` file. Flask sends requests to Gemini; the browser never receives the key. The `.env` file is excluded from Git.

## Data and model limits

DA snapshot prices are NCR market references, not local retail quotes. Unmatched items remain unpriced. Preparation-difficulty ratings are practical guide estimates. Overhead prediction remains disabled because its inherited training data is simulated and unvalidated; estimates cover direct ingredient costs only.



## Gemini reliability update

- Retries the configured Gemini model once after temporary HTTP 503/429/404 responses.
- Automatically tries stable text-capable backup models (`gemini-3.7-flash`, `gemini-3.6-flash`, `gemini-3.5-flash-lite`) when the configured model is overloaded, rate-limited, or unavailable.
- Shows the actual responding model in the AI connection status and labels backup-model use.
- Non-AI recipe, ingredient, and costing features remain local and available if all AI models are unavailable.


## V9 maintenance update (17 November 2026)

- Replaced the user-upload-first DA price workflow in Price Monitoring with backend retrieval of the newest dated DA Daily Price Index report. The page triggers a check on open and provides a manual sync button; a Flask background worker also checks every six hours while the local server is running, even when the browser tab is closed. This is periodic retrieval of DA's dated reference report, not a streaming live-price service.
- Added an Ingredients integrity summary endpoint, aligned status/category filters with database values, and connected ingredient add/edit/delete actions to Flask APIs. Deletion archives an ingredient from the active library without deleting its price history; records linked to saved recipes are protected. The edit form supports package price and size so package-normalized prices are not silently lost.
- Renamed the assistant UI to AI Analysis and added `/api/ai/analysis`, preserving the old endpoint as a compatibility alias. The assistant receives ingredient, saved-recipe, and price-history context.
- Added per-saved-recipe CSV downloads and upgraded the all-recipes export to include itemized ingredient cost and provenance details.
- Fixed the Price Monitoring history section's duplicate element ID and removed emoji-style navigation labels.
