# KusinA.I. V9 — Mac & VS Code setup

A local Flask + SQLite website for Filipino recipe building, ingredient price references, serving-level costing, and saved estimates. The project runs on macOS with Python 3.10+ and a browser.

## 1. Open the project on your Mac

1. Extract the updated `KusinAI_V9_Updated.zip` archive.
2. In VS Code, choose **File → Open Folder** and select the extracted `KusinAI_V9_Updated` folder—the folder containing `app.py`.
3. Open **Terminal → New Terminal**.
4. Create and activate the virtual environment:

   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

5. Install dependencies:

   ```bash
   python -m pip install --upgrade pip
   python -m pip install -r requirements.txt
   ```

6. Start the site:

   ```bash
   python app.py
   ```

7. Visit **http://127.0.0.1:5016**. To stop it, press **Control + C** in Terminal.

**One-click option:** double-click `run_mac.command`. The first run creates `.venv` and installs dependencies; the Terminal window hosts the local server while it is running.

### Open KusinA.I. again later

Each time you want to use the system, open the extracted project folder in VS Code and run `python app.py` in its activated `.venv` terminal. Keep that terminal running while using the site. Open `http://127.0.0.1:5016` in Safari or Chrome. The project is local to your Mac; closing the terminal stops the local server. The SQLite data is stored in `database.db`, so make a copy of that file before replacing the project with a newer archive.

## 2. Modules

- `/` — Landing page with links to the modules.
- `/predictor` — Scale a saved recipe to a new serving count and view its numbered cost breakdown.
- `/food` — Build/edit recipes using edible ingredient quantity **per serving**.
- `/ingredients` — Database-backed Ingredient Library with working search, category/status filters, Add, Edit, Archive/Remove, package-price editing, and SHA-256 integrity checks. Removing an item archives it from the active list while retaining its price-history audit trail; an item used by a saved recipe cannot be removed.
- `/saves` — Saved recipe summaries and itemized cost/source snapshots. Download an individual recipe CSV or export all saved recipes with their ingredient details.
- `/prices` — Automatic DA Daily Price Index checking, dated price history, source links, and a manual sync control. A PDF upload is not required for the automatic update path.
- `/favorites` — Redirects to `/saves` for old bookmarks.

Every page uses the shared navigation, Philippine date/time (Asia/Manila), and the **AI Analysis** assistant.

## 3. Gemini Flash / AI Analysis setup (no Firebase)

KusinA.I calls the Gemini Developer API from the Flask backend. The request uses the Gemini REST API `systemInstruction` field name. Firebase, Firebase AI Logic, App Check, and reCAPTCHA are not used.

1. Create a Gemini API key in [Google AI Studio](https://aistudio.google.com/app/apikey).
2. Open the included `.env` file beside `app.py` in VS Code.
3. Replace `PASTE_YOUR_GEMINI_API_KEY_HERE` with your private key. Do not add quotation marks.
4. Install the requirements (including `certifi`, which supplies a trusted CA bundle for HTTPS certificate verification on macOS).
5. Restart the app with `python app.py`.

The key is read only by the Python backend and is never sent to browser JavaScript. The delivered project includes a placeholder `.env`; add your own key locally. `.env` is excluded by `.gitignore`. Never commit or share the key. If a key was pasted into a chat or public location, revoke it and create a replacement.

## 4. How the recipe costing works

The Builder quantity is the **edible amount needed for one serving**. The app multiplies that value by the selected serving count to obtain the batch quantity. It then converts the edible amount to the exact DA or store-price unit, applies only documented yield loss, and calculates the line cost.

- Supported units: g, kg, mL, L, and each/pc.
- Allowed conversions: g ↔ kg, mL ↔ L, and each ↔ each.
- Not allowed without ingredient-specific verified data: mass ↔ volume or mass/volume ↔ pieces. The app never guesses density or piece weight.
- Purchased quantity = edible quantity ÷ (1 − documented yield-loss fraction).
- Ingredient line cost = purchased quantity × price per price unit.
- Batch cost = sum of the unrounded ingredient line costs, rounded to centavos.
- Cost per serving = batch cost ÷ serving count.

The detailed breakdown reports its line count and shows per-serving recipe quantity, batch quantity, converted edible amount, purchase quantity, price basis, yield loss, batch cost, and per-serving cost. Prices with no source/date and prices with incompatible units are blocked from costing. Package price + package size can be entered to normalize a price to PHP per kg, g, liter, mL, or piece, as long as the dimensions match.

**Scope:** production estimates currently cover direct ingredient cost only. Labor, utilities, rent, and overhead are not included because the supplied legacy overhead model was trained on simulated—not measured—observations and is not validated.

## 5. DA price dataset and limitations

The bundled reference snapshot is the DA **Daily Price Index dated 13 November 2026**, with 23 directly matched observations. Structured rows are provided in `data/da_daily_price_index_2026-11-13.csv`. The official PDF is: https://www.da.gov.ph/wp-content/uploads/2026/11/November-13-2026-DPI-AFC.pdf

**Important scope:** the report is an NCR market reference. It is not a store-specific checkout quote and should not be presented as an Antipolo or other provincial price. Commodity prices are generally PHP/kg, eggs are PHP/each, and the DA oil rows are PHP/liter. Oil varieties (palm, coconut, Minola, Spring, palm olein) are stored separately. Kangkong, repolyo, toyo, suka, and generic cooking oil have no matching observation in this daily report and are deliberately left unpriced rather than populated with an estimate.

For future prices, start KusinA.I. with `python app.py`. The Flask server checks the official DA Price Monitoring listing after startup and every six hours while the local server remains running, even when the browser tab is closed. It downloads the newest dated Daily Price Index PDF itself, parses it on the Flask backend, and imports only exact ingredient-name matches with compatible measurement units. Users do not need to upload the PDF. Opening **Price Monitoring** also triggers an immediate check, and its **Sync latest DA prices** button can request another check at any time. A newer dated observation can update the active reference; older reports are retained in history and do not roll the current price backward.

**Important update limitation:** the DA publishes dated market reports, not a streaming price feed. This is automated retrieval of the latest available DA report, not second-by-second or store-specific live pricing. The six-hour background recheck runs while the local Flask server is running. It pauses when the app is stopped or the Mac is asleep, and resumes after the app is started again. If the DA website is unreachable or the report format changes, the app keeps existing prices and displays an error instead of guessing. Prices are NCR market references, not store-specific quotations or provincial market prices. Automatic matching is deliberately conservative: unmatched commodities and incompatible units are skipped.

## 6. Preparation ratings and yield data

The 1–5 preparation rating describes practical effort (1 = very easy; 5 = very difficult) and includes a reason field. It is a usability guide, not a food-quality rating or experimentally validated scientific score.

Old yield-loss percentages without a traceable source have been cleared. A non-zero yield loss now requires a source; until one is recorded, the system applies 0% and clearly shows that yield was not verified. This avoids turning unsupported trimming assumptions into hidden extra costs.

## 7. Tests and troubleshooting

After installing requirements, run:

```bash
python -m unittest discover -s tests -v
python -m py_compile app.py
```

If port 5016 is already in use, run `KUSINAI_PORT=5017 python app.py` and visit `http://127.0.0.1:5017`. If `python3` is not found, install Python 3 from https://www.python.org/downloads/macos/ or use the Python installation provided by your school.

The database is `database.db`. Back it up before making substantial manual edits. The app creates schema/migration records automatically when it starts.


### Gemini reliability and fallback behavior

The AI assistant calls the Gemini Developer API from the local Flask server. If the configured model returns a temporary overload (HTTP 503), rate-limit (HTTP 429), or unavailable-model (HTTP 404) response, KusinA.I retries the configured model once and then tries these documented stable text models in order: `gemini-3.7-flash`, `gemini-3.6-flash`, and `gemini-3.5-flash-lite`. The AI status shows the model that answered and marks backup-model use. If all models are unavailable, wait briefly and retry. This does not affect the local recipe builder, ingredient library, or cost predictor.

