import csv
import io
import json
import math
import os
import sqlite3
import hashlib
import ssl
import time
import threading
import certifi
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from zoneinfo import ZoneInfo
import re
from html.parser import HTMLParser

from flask import Flask, Response, g, jsonify, redirect, render_template, request, send_from_directory
from dotenv import load_dotenv
from werkzeug.exceptions import HTTPException


BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")
DATABASE_PATH = Path(os.environ.get("KUSINAI_DATABASE_PATH", BASE_DIR / "database.db"))
SCHEMA_PATH = BASE_DIR / "src" / "db" / "schema.sql"
SUPPORTED_UNITS = {"g", "kg", "ml", "l", "each"}
MAX_PRICE_PDF_BYTES = 10 * 1024 * 1024
UNIT_FAMILY = {"g": "mass", "kg": "mass", "ml": "volume", "l": "volume", "each": "count"}
UNIT_TO_BASE = {"g": 1.0, "kg": 1000.0, "ml": 1.0, "l": 1000.0}
# The supplied overhead model was trained on simulated rows, not verified observations.
# It is deliberately not loaded into production estimates until empirical data is supplied.
OVERHEAD_MODEL_STATUS = "not_validated_simulated_training_data"
DA_AUTO_SYNC_LOCK = threading.Lock()

app = Flask(
    __name__,
    static_folder=str(BASE_DIR / "public"),
    static_url_path="",
    template_folder=str(BASE_DIR / "public"),
)

app.config["TEMPLATES_AUTO_RELOAD"] = True
app.jinja_env.auto_reload = True


@app.errorhandler(HTTPException)
def handle_http_exception(error):
    if request.path == "/api" or request.path.startswith("/api/"):
        return jsonify({"error": error.description, "status": error.code}), error.code
    return error


@app.after_request
def no_cache_for_pages(response):
    if response.mimetype in ("text/html", "text/javascript", "application/javascript"):
        response.headers["Cache-Control"] = "no-cache"
    return response


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(_error=None):
    database = g.pop("db", None)
    if database is not None:
        database.close()


def seed_latest_da_daily_index(database):
    """Seed only explicitly matched prices from the DA Daily Price Index dated 2026-11-13.

    These are NCR report references, not provincial or store-specific quotes.
    Missing commodities deliberately stay unpriced instead of receiving estimates.
    """
    migration_id = "seed_da_daily_index_2026_11_13_v1"
    if database.execute("SELECT 1 FROM schema_migrations WHERE migration_id = ?", (migration_id,)).fetchone():
        return

    source = "DA-AMAS Daily Price Index"
    report_type = "Daily Price Index"
    report_date = "2026-11-13"
    location = "NCR"
    filename = "November-13-2026-DPI-AFC.pdf"

    records = [
        ("Liempo", "Meat & Poultry", "kg", 368.19, "Pork belly (liempo), local fresh or chilled", 4,
         "Usually requires portioning and may need trimming; effort varies by cut and recipe."),
        ("Pork Kasim", "Meat & Poultry", "kg", 310.55, "Pork picnic shoulder (kasim), local fresh or chilled", 3,
         "Usually requires portioning and may need trimming; effort varies by cut and recipe."),
        ("Whole Chicken", "Meat & Poultry", "kg", 203.36, "Whole chicken, local", 4,
         "May require portioning, cleaning, or deboning depending on the recipe."),
        ("Chicken Breast", "Meat & Poultry", "kg", 218.79, "Chicken breast, local", 2,
         "Usually needs portioning and safe handling; preparation varies by recipe."),
        ("Beef Rump", "Meat & Poultry", "kg", 502.40, "Beef rump/tapadera, local", 3,
         "Usually needs portioning and may need trimming; effort varies by recipe."),
        ("Bangus", "Seafood", "kg", 243.59, "Bangus, medium (3–4 pcs/kg), local fresh", 4,
         "Cleaning and deboning may add steps; actual effort depends on how it is purchased."),
        ("Tilapia", "Seafood", "kg", 157.14, "Tilapia, medium, local fresh", 3,
         "Cleaning and scaling may add steps; actual effort depends on how it is purchased."),
        ("Galunggong", "Seafood", "kg", 306.17, "Galunggong, local male medium (12–14 pcs/kg)", 4,
         "Cleaning and scaling may add steps; actual effort depends on how it is purchased."),
        ("Sibuyas", "Vegetables", "kg", 125.52, "Red onion, local, medium", 2,
         "Usually needs peeling and slicing; effort depends on the quantity and cut."),
        ("Bawang", "Vegetables", "kg", 385.00, "Garlic, native/local", 3,
         "Usually needs peeling and chopping or crushing; effort depends on the recipe."),
        ("Kamatis", "Vegetables", "kg", 127.49, "Tomato, local/ripe", 2,
         "Usually needs washing and slicing; effort depends on the recipe."),
        ("Patatas", "Vegetables", "kg", 169.80, "White potato, local", 3,
         "Usually needs washing, peeling, and cutting; effort depends on the recipe."),
        ("Carrot", "Vegetables", "kg", 153.24, "Carrots, local", 2,
         "Usually needs washing, peeling, and cutting; effort depends on the recipe."),
        ("Talong", "Vegetables", "kg", 124.71, "Eggplant, local", 2,
         "Usually needs washing and cutting; effort depends on the recipe."),
        ("Ampalaya", "Vegetables", "kg", 111.26, "Bitter gourd (ampalaya), local", 3,
         "Usually needs washing, slicing, and seed removal; effort depends on the recipe."),
        ("Kalabasa", "Vegetables", "kg", 61.08, "Squash, local", 3,
         "Usually needs peeling and cutting; effort depends on the recipe."),
        ("Regular Milled Rice", "Staples", "kg", 45.29, "Regular milled rice, local commercial", 1,
         "Basic measuring and rinsing only for the standard preparation method."),
        ("Chicken Egg (White, Medium)", "Meat & Poultry", "each", 8.21, "Chicken egg (white, medium), 56–60 g/pc", 1,
         "Basic cracking and portioning only; handling depends on the recipe."),
        ("Cooking Oil (Palm)", "Pantry", "l", 103.47, "Cooking oil (palm), DA-listed commodity class", 1,
         "Basic measuring only; this is a practical guide estimate."),
        ("Cooking Oil (Coconut)", "Pantry", "l", 151.52, "Cooking oil (coconut), DA-listed commodity class", 1,
         "Basic measuring only; this is a practical guide estimate."),
        ("Cooking Oil (Minola)", "Pantry", "l", 183.33, "Cooking oil (Minola), DA-listed commodity class", 1,
         "Basic measuring only; this is a practical guide estimate."),
        ("Cooking Oil (Spring)", "Pantry", "l", 150.00, "Cooking oil (Spring), DA-listed commodity class", 1,
         "Basic measuring only; this is a practical guide estimate."),
        ("Cooking Oil (Palm Olein)", "Pantry", "l", 164.00, "Cooking oil (palm olein), DA-listed commodity class", 1,
         "Basic measuring only; this is a practical guide estimate."),
    ]

    batch = database.execute(
        "INSERT INTO price_import_batches(filename,source,report_type,report_date,location,records_found,records_imported) "
        "VALUES(?,?,?,?,?,?,?)",
        (filename, source, report_type, report_date, location, len(records), len(records)),
    )
    batch_id = batch.lastrowid
    for name, category, unit, price, specification, complexity, reason in records:
        row = database.execute("SELECT id FROM ingredients WHERE lower(name)=lower(?)", (name,)).fetchone()
        if row is None:
            cursor = database.execute(
                "INSERT INTO ingredients (name,category,unit_measure,price_unit,market_price,price_source,price_date,"
                "price_status,price_type,record_scope,product_specification,price_location,price_report_type,"
                "market_reference_confirmed,yield_loss,yield_source,complexity,complexity_reason) "
                "VALUES(?,?,?,?,?,?,?,'documented','market_reference','product_specific',?,?,?,0,0,NULL,?,?)",
                (name, category, unit, unit, price, source, report_date, specification, location,
                 report_type, complexity, reason),
            )
            ingredient_id = cursor.lastrowid
        else:
            ingredient_id = row[0]
            database.execute(
                "UPDATE ingredients SET category=?,unit_measure=?,price_unit=?,market_price=?,price_source=?,"
                "price_date=?,price_status='documented',price_type='market_reference',record_scope='product_specific',"
                "product_specification=?,price_location=?,price_report_type=?,market_reference_confirmed=0,"
                "yield_loss=CASE WHEN COALESCE(trim(yield_source),'')='' THEN 0 ELSE yield_loss END,"
                "complexity=?,complexity_reason=COALESCE(NULLIF(complexity_reason,''),?),"
                "updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (category, unit, unit, price, source, report_date, specification, location, report_type,
                 complexity, reason, ingredient_id),
            )
        existing_history = database.execute(
            "SELECT 1 FROM ingredient_price_history WHERE ingredient_id=? AND report_date=? AND source=? "
            "AND report_type=? LIMIT 1", (ingredient_id, report_date, source, report_type),
        ).fetchone()
        if not existing_history:
            database.execute(
                "INSERT INTO ingredient_price_history(ingredient_id,ingredient_name,specification,price,price_unit,"
                "report_type,report_date,source,location,import_batch_id,price_type,market_reference_confirmed) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,0)",
                (ingredient_id, name, specification, price, unit, report_type, report_date, source, location,
                 batch_id, "market_reference"),
            )

    # Legacy yield-loss values lacked a traceable source. Remove them rather than
    # silently charging for a guessed purchase quantity. The explanation is visible in the UI.
    database.execute(
        "UPDATE ingredients SET yield_loss=0,"
        "complexity_reason=COALESCE(NULLIF(complexity_reason,''),"
        "'Practical preparation guide estimate only; adjust to the actual method. Not experimentally validated.') "
        "WHERE COALESCE(trim(yield_source),'')=''")

    # Never preserve fabricated placeholder prices where the official report did not
    # provide an exact, compatible commodity observation.
    unpriced = ("Kangkong", "Repolyo", "Cooking Oil", "Toyo", "Suka")
    for name in unpriced:
        database.execute(
            "UPDATE ingredients SET market_price=0,price_source=NULL,price_date=NULL,price_status='unverified',"
            "price_location=NULL,price_report_type=NULL,product_specification=NULL,price_unit=unit_measure,"
            "package_size=NULL,package_unit=NULL,package_purchase_price=NULL,market_reference_confirmed=0 "
            "WHERE lower(name)=lower(?)", (name,),
        )

    database.execute("INSERT INTO schema_migrations(migration_id) VALUES(?)", (migration_id,))


def init_db():
    with sqlite3.connect(DATABASE_PATH) as database:
        database.row_factory = sqlite3.Row
        database.execute("PRAGMA foreign_keys = ON")
        database.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))
        database.execute(
            "CREATE TABLE IF NOT EXISTS saved_recipes ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "recipe_name TEXT NOT NULL, "
            "servings INTEGER NOT NULL CHECK (servings > 0), "
            "total_cost REAL NOT NULL CHECK (total_cost >= 0), "
            "cost_per_serving REAL NOT NULL CHECK (cost_per_serving >= 0), "
            "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"
        )
        database.execute(
            "CREATE TABLE IF NOT EXISTS serving_parameters ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "recipe_name TEXT NOT NULL, "
            "serving_count REAL NOT NULL CHECK (serving_count > 0), "
            "target_portion_grams REAL CHECK (target_portion_grams IS NULL OR target_portion_grams > 0), "
            "waste_buffer_percent REAL NOT NULL DEFAULT 0 CHECK (waste_buffer_percent >= 0 AND waste_buffer_percent < 100), "
            "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"
        )
        columns = {row[1] for row in database.execute("PRAGMA table_info(ingredients)")}
        if "integrity_hash" not in columns:
            database.execute("ALTER TABLE ingredients ADD COLUMN integrity_hash TEXT")
        if "is_active" not in columns:
            database.execute("ALTER TABLE ingredients ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1))")
        if "price_unit" not in columns:
            database.execute("ALTER TABLE ingredients ADD COLUMN price_unit TEXT NOT NULL DEFAULT 'kg'")
            database.execute("UPDATE ingredients SET price_unit = unit_measure")
        if "price_source" not in columns:
            database.execute("ALTER TABLE ingredients ADD COLUMN price_source TEXT")
        if "price_date" not in columns:
            database.execute("ALTER TABLE ingredients ADD COLUMN price_date TEXT")
        if "yield_source" not in columns:
            database.execute("ALTER TABLE ingredients ADD COLUMN yield_source TEXT")
        # Price provenance is explicit: a generic market reference is not the same
        # thing as a price for a named retail product/package.
        for column, definition in (
            ("price_status", "TEXT NOT NULL DEFAULT 'unverified'"),
            ("price_type", "TEXT NOT NULL DEFAULT 'market_reference'"),
            ("record_scope", "TEXT NOT NULL DEFAULT 'generic'"),
            ("product_specification", "TEXT"),
            ("package_size", "REAL"),
            ("package_unit", "TEXT"),
            ("package_purchase_price", "REAL"),
            ("price_location", "TEXT"),
            ("price_report_type", "TEXT"),
            ("market_reference_confirmed", "INTEGER NOT NULL DEFAULT 0"),
        ):
            if column not in columns:
                database.execute(f"ALTER TABLE ingredients ADD COLUMN {column} {definition}")
        columns = {row[1] for row in database.execute("PRAGMA table_info(ingredients)")}
        database.execute(
            "UPDATE ingredients SET price_status = 'documented' "
            "WHERE price_status = 'unverified' AND price_source IS NOT NULL AND price_date IS NOT NULL"
        )
        database.execute(
            "CREATE TABLE IF NOT EXISTS saved_recipe_items ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, recipe_id INTEGER NOT NULL, "
            "ingredient_id INTEGER, ingredient_name TEXT NOT NULL, quantity REAL NOT NULL, "
            "quantity_unit TEXT NOT NULL, as_purchased_quantity REAL NOT NULL, "
            "price_unit TEXT NOT NULL, unit_price REAL NOT NULL, line_cost REAL NOT NULL, "
            "yield_loss_percent REAL NOT NULL DEFAULT 0, price_source TEXT, price_date TEXT, yield_source TEXT, "
            "price_type TEXT, product_specification TEXT, package_size REAL, package_unit TEXT, package_purchase_price REAL, "
            "price_location TEXT, price_report_type TEXT, market_reference_confirmed INTEGER NOT NULL DEFAULT 0, "
            "FOREIGN KEY(recipe_id) REFERENCES saved_recipes(id) ON DELETE CASCADE)"
        )
        database.execute(
            "CREATE TABLE IF NOT EXISTS ingredient_price_history ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, ingredient_id INTEGER NOT NULL, "
            "ingredient_name TEXT NOT NULL, specification TEXT, price REAL NOT NULL CHECK(price >= 0), "
            "price_unit TEXT NOT NULL, report_type TEXT NOT NULL, report_date TEXT NOT NULL, "
            "source TEXT NOT NULL, location TEXT NOT NULL DEFAULT 'NCR', imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, "
            "import_batch_id INTEGER, price_type TEXT NOT NULL DEFAULT 'market_reference', package_size REAL, package_unit TEXT, package_purchase_price REAL, "
            "market_reference_confirmed INTEGER NOT NULL DEFAULT 0, "
            "FOREIGN KEY(ingredient_id) REFERENCES ingredients(id))"
        )
        database.execute(
            "CREATE TABLE IF NOT EXISTS recipes ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, recipe_name TEXT NOT NULL UNIQUE, "
            "servings INTEGER NOT NULL CHECK(servings > 0), "
            "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, "
            "updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"
        )
        database.execute(
            "CREATE TABLE IF NOT EXISTS recipe_ingredients ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, recipe_id INTEGER NOT NULL, "
            "ingredient_id INTEGER NOT NULL, quantity REAL NOT NULL CHECK(quantity > 0), "
            "quantity_unit TEXT NOT NULL CHECK(quantity_unit IN ('g','kg','ml','l','each')), "
            "FOREIGN KEY(recipe_id) REFERENCES recipes(id) ON DELETE CASCADE, "
            "FOREIGN KEY(ingredient_id) REFERENCES ingredients(id) ON DELETE RESTRICT, "
            "UNIQUE(recipe_id, ingredient_id))"
        )
        database.execute(
            "CREATE TABLE IF NOT EXISTS price_import_batches ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT NOT NULL, source TEXT NOT NULL, "
            "report_type TEXT NOT NULL, report_date TEXT NOT NULL, location TEXT NOT NULL, "
            "records_found INTEGER NOT NULL DEFAULT 0, records_imported INTEGER NOT NULL DEFAULT 0, "
            "imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"
        )
        database.execute(
            "CREATE TABLE IF NOT EXISTS quarantine_records ("
            "id INTEGER PRIMARY KEY AUTOINCREMENT, "
            "source_type TEXT NOT NULL DEFAULT 'unknown', "
            "source_filename TEXT, "
            "source TEXT, "
            "report_type TEXT, "
            "report_date TEXT, "
            "location TEXT, "
            "ingredient_id INTEGER, "
            "ingredient_name TEXT, "
            "raw_data TEXT NOT NULL, "
            "validation_status TEXT NOT NULL DEFAULT 'quarantined' "
            "CHECK(validation_status IN ('quarantined','approved','rejected')), "
            "quarantine_reason TEXT NOT NULL, "
            "validation_errors TEXT, "
            "review_note TEXT, "
            "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, "
            "reviewed_at TEXT, "
            "reviewed_by TEXT, "
            "approved_at TEXT, "
            "FOREIGN KEY(ingredient_id) REFERENCES ingredients(id) ON DELETE SET NULL)"
        )
        database.execute(
            "CREATE INDEX IF NOT EXISTS idx_quarantine_status "
            "ON quarantine_records(validation_status)"
        )
        database.execute(
            "CREATE INDEX IF NOT EXISTS idx_quarantine_created_at "
            "ON quarantine_records(created_at)"
        )
        saved_item_columns = {row[1] for row in database.execute("PRAGMA table_info(saved_recipe_items)")}
        for column, definition in (
            ("yield_loss_percent", "REAL NOT NULL DEFAULT 0"), ("price_source", "TEXT"),
            ("price_date", "TEXT"), ("yield_source", "TEXT"), ("price_type", "TEXT"),
            ("product_specification", "TEXT"), ("package_size", "REAL"),
            ("package_unit", "TEXT"), ("package_purchase_price", "REAL"),
            ("price_location", "TEXT"), ("price_report_type", "TEXT"),
            ("market_reference_confirmed", "INTEGER NOT NULL DEFAULT 0"),
        ):
            if column not in saved_item_columns:
                database.execute(f"ALTER TABLE saved_recipe_items ADD COLUMN {column} {definition}")
        history_columns = {row[1] for row in database.execute("PRAGMA table_info(ingredient_price_history)")}
        for column, definition in (
            ("price_type", "TEXT NOT NULL DEFAULT 'market_reference'"),
            ("package_size", "REAL"), ("package_unit", "TEXT"),
            ("package_purchase_price", "REAL"),
            ("market_reference_confirmed", "INTEGER NOT NULL DEFAULT 0"),
        ):
            if column not in history_columns:
                database.execute(f"ALTER TABLE ingredient_price_history ADD COLUMN {column} {definition}")
        if "yield_loss" not in columns:
            database.execute(
                "ALTER TABLE ingredients ADD COLUMN yield_loss REAL NOT NULL DEFAULT 0 "
                "CHECK (yield_loss >= 0 AND yield_loss < 1)"
            )
        if "complexity" not in columns:
            database.execute(
                "ALTER TABLE ingredients ADD COLUMN complexity INTEGER NOT NULL DEFAULT 1 "
                "CHECK (complexity BETWEEN 1 AND 5)"
            )
        if "complexity_reason" not in columns:
            database.execute("ALTER TABLE ingredients ADD COLUMN complexity_reason TEXT")

        database.execute(
            "CREATE TABLE IF NOT EXISTS schema_migrations ("
            "migration_id TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"
        )
        legacy_migration = "preserve_legacy_condiment_price_basis_v1"
        if not database.execute(
            "SELECT 1 FROM schema_migrations WHERE migration_id = ?", (legacy_migration,)
        ).fetchone():
            legacy_rows = database.execute(
                "SELECT id, name, market_price, price_unit, price_source, price_date, price_type, "
                "product_specification, package_size, package_unit, package_purchase_price, "
                "price_location, price_report_type, market_reference_confirmed "
                "FROM ingredients WHERE lower(name) IN ('cooking oil', 'toyo', 'suka') "
                "AND unit_measure = 'kg' AND price_unit = 'kg'"
            ).fetchall()
            for row in legacy_rows:
                if row["price_source"] and row["price_date"]:
                    exists = database.execute(
                        "SELECT 1 FROM ingredient_price_history WHERE ingredient_id = ? "
                        "AND report_date = ? AND source = ? AND specification = ? LIMIT 1",
                        (row["id"], row["price_date"], row["price_source"], row["product_specification"]),
                    ).fetchone()
                    if not exists:
                        database.execute(
                            "INSERT INTO ingredient_price_history "
                            "(ingredient_id, ingredient_name, specification, price, price_unit, report_type, "
                            "report_date, source, location, price_type, package_size, package_unit, "
                            "package_purchase_price, market_reference_confirmed) "
                            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                            (row["id"], row["name"], row["product_specification"], row["market_price"],
                             row["price_unit"], row["price_report_type"] or "Legacy price snapshot",
                             row["price_date"], row["price_source"], row["price_location"] or "Not recorded",
                             row["price_type"], row["package_size"], row["package_unit"],
                             row["package_purchase_price"], row["market_reference_confirmed"]),
                        )
                database.execute(
                    "UPDATE ingredients SET unit_measure='ml', price_unit='ml', market_price=0, "
                    "price_source=NULL, price_date=NULL, price_status='unverified', "
                    "price_type='market_reference', record_scope='generic', product_specification=NULL, "
                    "package_size=NULL, package_unit=NULL, package_purchase_price=NULL, "
                    "price_location=NULL, price_report_type=NULL, market_reference_confirmed=0 "
                    "WHERE id=? AND unit_measure='kg'",
                    (row["id"],),
                )
            database.execute(
                "INSERT INTO schema_migrations (migration_id) VALUES (?)", (legacy_migration,)
            )

        ingredient_count = database.execute(
            "SELECT COUNT(*) FROM ingredients"
        ).fetchone()[0]
        if ingredient_count == 0:
            database.executemany(
                "INSERT INTO ingredients "
                "(name, category, unit_measure, market_price, yield_loss, complexity) "
                "VALUES (?, ?, 'kg', ?, ?, ?)",
                [
                    ("Liempo", "Meat & Poultry", 0.0, 0.0, 4),
                    ("Pork Kasim", "Meat & Poultry", 0.0, 0.0, 3),
                    ("Whole Chicken", "Meat & Poultry", 0.0, 0.0, 4),
                    ("Chicken Breast", "Meat & Poultry", 0.0, 0.0, 2),
                    ("Beef Rump", "Meat & Poultry", 0.0, 0.0, 3),
                    ("Bangus", "Seafood", 0.0, 0.0, 4),
                    ("Tilapia", "Seafood", 0.0, 0.0, 3),
                    ("Galunggong", "Seafood", 0.0, 0.0, 4),
                    ("Sibuyas", "Vegetables", 0.0, 0.0, 3),
                    ("Bawang", "Vegetables", 0.0, 0.0, 4),
                    ("Kamatis", "Vegetables", 0.0, 0.0, 2),
                    ("Patatas", "Vegetables", 0.0, 0.0, 3),
                    ("Carrot", "Vegetables", 0.0, 0.0, 3),
                    ("Talong", "Vegetables", 0.0, 0.0, 2),
                    ("Ampalaya", "Vegetables", 0.0, 0.0, 3),
                    ("Kalabasa", "Vegetables", 0.0, 0.0, 3),
                    ("Kangkong", "Vegetables", 0.0, 0.0, 2),
                    ("Repolyo", "Vegetables", 0.0, 0.0, 2),
                    ("Cooking Oil", "Pantry", 0.0, 0.0, 1),
                    ("Toyo", "Pantry", 0.0, 0.0, 1),
                    ("Suka", "Pantry", 0.0, 0.0, 1),
                    ("Regular Milled Rice", "Staples", 0.0, 0.0, 1),
                ],
            )
            database.execute(
                "UPDATE ingredients SET unit_measure = 'ml', price_unit = 'ml', market_price = 0, "
                "price_status = 'unverified' WHERE lower(name) IN ('cooking oil', 'toyo', 'suka')"
            )
        seed_latest_da_daily_index(database)
        hash_rows = database.execute(
            "SELECT id, name, category, unit_measure, price_unit, market_price, price_source, price_date, "
            "price_status, price_type, record_scope, product_specification, package_size, package_unit, "
            "package_purchase_price, price_location, price_report_type, market_reference_confirmed, "
            "yield_source, yield_loss, complexity, complexity_reason, integrity_hash FROM ingredients"
        ).fetchall()
        for hash_row in hash_rows:
            if not hash_row["integrity_hash"]:
                database.execute(
                    "UPDATE ingredients SET integrity_hash=? WHERE id=?",
                    (calculate_integrity_hash(hash_row), hash_row["id"]),
                )
    database.close()

def ingredient_hash_payload(row):
    """Build the canonical ingredient data used for SHA-256 integrity hashing."""
    if row is None:
        return {}

    keys = set(row.keys()) if hasattr(row, "keys") else set(dict(row).keys())

    def value(name, default=None):
        return row[name] if name in keys else default

    return {
        "id": value("id"),
        "name": value("name"),
        "category": value("category"),
        "unit_measure": value("unit_measure"),
        "price_unit": value("price_unit"),
        "market_price": value("market_price"),
        "price_source": value("price_source"),
        "price_date": value("price_date"),
        "price_status": value("price_status"),
        "price_type": value("price_type"),
        "record_scope": value("record_scope"),
        "product_specification": value("product_specification"),
        "package_size": value("package_size"),
        "package_unit": value("package_unit"),
        "package_purchase_price": value("package_purchase_price"),
        "price_location": value("price_location"),
        "price_report_type": value("price_report_type"),
        "market_reference_confirmed": value("market_reference_confirmed", 0),
        "yield_source": value("yield_source"),
        "yield_loss": value("yield_loss", 0),
        "complexity": value("complexity", 1),
        "complexity_reason": value("complexity_reason"),
    }

def calculate_integrity_hash(row):
    """Generate a deterministic SHA-256 hash for an ingredient record."""
    payload = ingredient_hash_payload(row)

    canonical_data = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        default=str,
    )

    return hashlib.sha256(canonical_data.encode("utf-8")).hexdigest()


def refresh_ingredient_hash(database, ingredient_id):
    """Recalculate and store the current SHA-256 integrity hash."""
    row = database.execute(
        "SELECT id, name, category, unit_measure, price_unit, market_price, "
        "price_source, price_date, price_status, price_type, record_scope, "
        "product_specification, package_size, package_unit, package_purchase_price, "
        "price_location, price_report_type, market_reference_confirmed, "
        "yield_source, yield_loss, complexity, complexity_reason "
        "FROM ingredients WHERE id = ?",
        (ingredient_id,),
    ).fetchone()

    if row is None:
        return None

    integrity_hash = calculate_integrity_hash(row)

    database.execute(
        "UPDATE ingredients SET integrity_hash = ? WHERE id = ?",
        (integrity_hash, ingredient_id),
    )

    return integrity_hash


def verify_ingredient_integrity(database, ingredient_id):
    """Compare the stored hash with a freshly calculated hash."""
    row = database.execute(
        "SELECT id, name, category, unit_measure, price_unit, market_price, "
        "price_source, price_date, price_status, price_type, record_scope, "
        "product_specification, package_size, package_unit, package_purchase_price, "
        "price_location, price_report_type, market_reference_confirmed, "
        "yield_source, yield_loss, complexity, complexity_reason, integrity_hash "
        "FROM ingredients WHERE id = ?",
        (ingredient_id,),
    ).fetchone()

    if row is None:
        return None

    current_hash = calculate_integrity_hash(row)
    stored_hash = row["integrity_hash"]

    return {
        "ingredientId": ingredient_id,
        "ingredientName": row["name"],
        "storedHash": stored_hash,
        "currentHash": current_hash,
        "integrityStatus": "verified" if stored_hash == current_hash else "mismatch",
        "hashAlgorithm": "SHA-256",
    }

def ingredient_from_row(row):
    keys = set(row.keys())
    price_date = row["price_date"] if "price_date" in keys else None
    price_age_days = None
    if price_date:
        try:
            observed = datetime.strptime(price_date, "%Y-%m-%d").date()
            price_age_days = max(0, (datetime.now(ZoneInfo("Asia/Manila")).date() - observed).days)
        except (TypeError, ValueError):
            price_age_days = None
    return {
        "id": row["id"], "name": row["name"], "category": row["category"],
        "unitMeasure": row["unit_measure"], "priceUnit": row["price_unit"] if "price_unit" in keys else row["unit_measure"],
        "marketPrice": row["market_price"],
        "priceSource": row["price_source"] if "price_source" in keys else None,
        "priceDate": price_date,
        "priceAgeDays": price_age_days,
        "priceFreshness": ("fresh" if price_age_days is not None and price_age_days <= 7 else "older_reference" if price_age_days is not None else "undated"),
        "priceStatus": row["price_status"] if "price_status" in keys else ("documented" if row["price_source"] and row["price_date"] else "unverified"),
        "priceType": row["price_type"] if "price_type" in keys else "market_reference",
        "recordScope": row["record_scope"] if "record_scope" in keys else "generic",
        "productSpecification": row["product_specification"] if "product_specification" in keys else None,
        "packageSize": row["package_size"] if "package_size" in keys else None,
        "packageUnit": row["package_unit"] if "package_unit" in keys else None,
        "packagePurchasePrice": row["package_purchase_price"] if "package_purchase_price" in keys else None,
        "priceLocation": row["price_location"] if "price_location" in keys else None,
        "priceReportType": row["price_report_type"] if "price_report_type" in keys else None,
        "marketReferenceConfirmed": bool(row["market_reference_confirmed"]) if "market_reference_confirmed" in keys else False,
        "unitCompatibility": UNIT_FAMILY.get(row["unit_measure"]) == UNIT_FAMILY.get(row["price_unit"] if "price_unit" in keys else row["unit_measure"]),
        "yieldSource": row["yield_source"] if "yield_source" in keys else None,
        "yieldDataStatus": "documented" if (row["yield_source"] if "yield_source" in keys else None) and row["yield_loss"] > 0 else "not_verified",
        "preparationAttributes": {
            "complexityScore": row["complexity"],
            "complexityLabel": ["", "Very easy", "Easy", "Moderate", "Difficult", "Very difficult"][int(row["complexity"])],
            "complexityReason": row["complexity_reason"] if "complexity_reason" in keys else None,
            "ratingMethod": "Practical guide estimate; not an experimentally validated score",
            "yieldLossPercent": round(row["yield_loss"] * 100, 2),
        },
        "createdAt": row["created_at"],
"updatedAt": row["updated_at"],
"integrityHash": row["integrity_hash"] if "integrity_hash" in keys else None,
    }


def convert_quantity(quantity, from_unit, to_unit):
    """Convert compatible units only; never infer density or piece weight."""
    if from_unit not in SUPPORTED_UNITS or to_unit not in SUPPORTED_UNITS:
        raise ValueError("Unsupported unit. Use g, kg, ml, l, or each.")
    if UNIT_FAMILY[from_unit] != UNIT_FAMILY[to_unit]:
        raise ValueError(f"Cannot convert {from_unit} to {to_unit}; mass, volume, and piece units are not interchangeable without ingredient-specific density or piece-weight data.")
    if from_unit == "each" and to_unit == "each":
        return quantity
    return quantity * UNIT_TO_BASE[from_unit] / UNIT_TO_BASE[to_unit]


def decimal_convert_quantity(quantity, from_unit, to_unit):
    """Decimal-backed counterpart for the monetary costing path."""
    if from_unit not in SUPPORTED_UNITS or to_unit not in SUPPORTED_UNITS:
        raise ValueError("Unsupported unit. Use g, kg, ml, l, or each.")
    if UNIT_FAMILY[from_unit] != UNIT_FAMILY[to_unit]:
        raise ValueError(f"Cannot convert {from_unit} to {to_unit}; mass, volume, and piece units are not interchangeable without ingredient-specific density or piece-weight data.")
    if from_unit == "each" and to_unit == "each":
        return Decimal(str(quantity))
    from_factor = Decimal(str(UNIT_TO_BASE[from_unit]))
    to_factor = Decimal(str(UNIT_TO_BASE[to_unit]))
    return Decimal(str(quantity)) * from_factor / to_factor


def money_decimal(value):
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def calculate_recipe_cost(items, servings):
    if not isinstance(items, list) or not items:
        raise ValueError("Add at least one ingredient with a measured quantity.")
    if isinstance(servings, bool) or not isinstance(servings, int) or servings < 1:
        raise ValueError("servings must be a positive whole number.")
    db = get_db()
    breakdown = []
    unrounded_line_costs = []
    for item in items:
        if not isinstance(item, dict):
            raise ValueError("Each ingredient line must be an object.")
        ingredient_id = item.get("ingredient_id", item.get("id"))
        quantity = item.get("quantity")
        quantity_unit = item.get("unit", item.get("quantity_unit"))
        if isinstance(ingredient_id, bool) or not isinstance(ingredient_id, int):
            raise ValueError("Each ingredient must reference a valid ingredient record.")
        if not is_number(quantity) or quantity <= 0:
            raise ValueError("Ingredient quantities must be greater than zero.")
        if quantity_unit not in SUPPORTED_UNITS:
            raise ValueError("Ingredient quantity units must be g, kg, ml, l, or each.")
        row = db.execute(
            "SELECT id, name, unit_measure, price_unit, market_price, price_source, price_date, price_status, "
            "price_type, record_scope, product_specification, package_size, package_unit, package_purchase_price, "
            "price_location, price_report_type, market_reference_confirmed, yield_source, yield_loss, complexity, complexity_reason "
            "FROM ingredients WHERE id = ? AND is_active=1", (ingredient_id,)
        ).fetchone()
        if row is None:
            raise ValueError(f"Ingredient record {ingredient_id} was not found.")
        price_unit = row["price_unit"] or row["unit_measure"]
        price_status = row["price_status"] if "price_status" in row.keys() else ("documented" if row["price_source"] and row["price_date"] else "unverified")
        if price_status != "documented":
            raise ValueError(f"{row['name']} has no documented usable price yet. Add a dated market reference or a verified product/package price in the Ingredient Library before calculating costs.")
        price_type = row["price_type"] if "price_type" in row.keys() else "market_reference"
        record_scope = row["record_scope"] if "record_scope" in row.keys() else "generic"
        product_specification = row["product_specification"] if "product_specification" in row.keys() else None
        reference_confirmed = bool(row["market_reference_confirmed"]) if "market_reference_confirmed" in row.keys() else False
        if UNIT_FAMILY.get(row["unit_measure"]) != UNIT_FAMILY.get(price_unit):
            raise ValueError(
                f"{row['name']} has an incompatible recipe unit and price unit; "
                "mass, volume, and piece units are not interchangeable without ingredient-specific conversion data."
            )
        if price_type == "verified_product" and record_scope != "product_specific":
            raise ValueError(f"{row['name']} is a generic ingredient and cannot use a verified product price.")
        if price_type == "market_reference" and record_scope == "generic" and product_specification and not reference_confirmed:
            raise ValueError(f"{row['name']} has a variant-specific market reference that needs explicit confirmation before costing.")
        # Do the arithmetic in Decimal so the final peso amounts are not affected
        # by binary floating-point representation. Keep unit conversion exact.
        decimal_convert_quantity(quantity, quantity_unit, row["unit_measure"])
        edible_in_price_unit = decimal_convert_quantity(quantity, quantity_unit, price_unit)
        yield_fraction = Decimal(str(row["yield_loss"]))
        yield_source = row["yield_source"]
        if yield_fraction > 0 and not (yield_source and str(yield_source).strip()):
            raise ValueError(f"{row['name']} has an undocumented yield-loss value. Add a traceable yield source or set yield loss to 0% before calculating.")
        as_purchased_quantity = edible_in_price_unit / (Decimal("1") - yield_fraction)
        market_price = Decimal(str(row["market_price"]))
        line_cost = as_purchased_quantity * market_price
        unrounded_line_costs.append(line_cost)
        line_cost_php = money_decimal(line_cost)
        per_serving_cost_php = money_decimal(line_cost / Decimal(servings))
        breakdown.append({
            "ingredient_id": row["id"], "name": row["name"],
            "recipe_quantity": round(float(quantity), 4), "recipe_quantity_per_serving": round(float(Decimal(str(quantity)) / Decimal(servings)), 4), "recipe_unit": quantity_unit,
            "edible_quantity_in_price_unit": round(float(edible_in_price_unit), 4),
            "as_purchased_quantity": round(float(as_purchased_quantity), 4),
            "price_unit": price_unit, "market_price_per_unit": float(market_price),
            "yield_loss_percent": round(float(yield_fraction * Decimal("100")), 2),
            "unit_cost": round(float(market_price / (Decimal("1") - yield_fraction)), 4),
            "line_cost_php": float(line_cost_php),
            "cost_per_serving_php": float(per_serving_cost_php),
            "complexity_score": int(row["complexity"]),
            "complexity_reason": row["complexity_reason"],
            "price_source": row["price_source"], "price_date": row["price_date"],
            "price_age_days": (max(0, (datetime.now(ZoneInfo("Asia/Manila")).date() - datetime.strptime(row["price_date"], "%Y-%m-%d").date()).days) if row["price_date"] else None),
            "yield_source": yield_source,
            "yield_data_status": "documented" if yield_fraction > 0 and yield_source else "not_verified",
            "price_type": price_type, "record_scope": record_scope,
            "product_specification": product_specification,
            "package_size": row["package_size"] if "package_size" in row.keys() else None,
            "package_unit": row["package_unit"] if "package_unit" in row.keys() else None,
            "package_purchase_price": row["package_purchase_price"] if "package_purchase_price" in row.keys() else None,
            "price_location": row["price_location"] if "price_location" in row.keys() else None,
            "price_report_type": row["price_report_type"] if "price_report_type" in row.keys() else None,
            "market_reference_confirmed": reference_confirmed,
            "price_reference_label": (
                f"Provisional market reference: {product_specification}"
                if price_type == "market_reference" and product_specification
                else f"Verified product: {product_specification}"
                if price_type == "verified_product" and product_specification
                else "Market reference"
            ),
        })
    direct_total = float(money_decimal(sum(unrounded_line_costs, Decimal("0"))))
    return {
        "servings": servings, "breakdown_count": len(breakdown), "ingredient_breakdown": breakdown,
        "direct_ingredient_cost_php": direct_total,
        "direct_cost_per_serving_php": float(money_decimal(Decimal(str(direct_total)) / Decimal(servings))),
        "predicted_overhead_cost_php": None,
        "overhead_model_status": OVERHEAD_MODEL_STATUS,
        "total_estimated_cost_php": direct_total,
        "cost_per_serving_php": float(money_decimal(Decimal(str(direct_total)) / Decimal(servings))),
        "cost_scope": "direct_ingredients_only_overhead_not_validated",
        "research_note": "Overhead prediction is excluded because the supplied training file is simulated and is not traceable to the institutional observations described in the paper.",
    }


def normalize_package_price(payload):
    """Return normalized unit price and package metadata when package fields are supplied."""
    package_price = payload.get("packagePurchasePrice")
    package_size = payload.get("packageSize")
    package_unit = payload.get("packageUnit")
    price_unit = payload.get("priceUnit", payload.get("unitMeasure"))
    unit_measure = payload.get("unitMeasure", price_unit)
    if price_unit not in SUPPORTED_UNITS or unit_measure not in SUPPORTED_UNITS:
        raise ValueError("Recipe and price units must be g, kg, ml, l, or each.")
    if UNIT_FAMILY[unit_measure] != UNIT_FAMILY[price_unit]:
        raise ValueError("Recipe unit and price unit must belong to the same measurement family.")
    if package_price in (None, "") and package_size in (None, ""):
        return payload.get("marketPrice"), None, None, None
    if not is_number(package_price) or package_price < 0 or not is_number(package_size) or package_size <= 0:
        raise ValueError("Enter a valid package purchase price and package size.")
    if package_unit not in SUPPORTED_UNITS or UNIT_FAMILY[package_unit] != UNIT_FAMILY[price_unit]:
        raise ValueError("Package unit and price unit must belong to the same measurement family.")
    normalized_quantity = convert_quantity(float(package_size), package_unit, price_unit)
    normalized_price = float(package_price) / normalized_quantity
    return normalized_price, float(package_size), package_unit, float(package_price)


def validate_ingredient(payload):
    required_fields = ("name", "category", "unitMeasure", "marketPrice")
    missing_field = next((field for field in required_fields if field not in payload), None)
    if missing_field:
        return f"{missing_field} is required"
    if not isinstance(payload["name"], str) or not payload["name"].strip():
        return "name must be a non-empty string"
    if not isinstance(payload["category"], str) or not payload["category"].strip():
        return "category must be a non-empty string"
    if payload["unitMeasure"] not in SUPPORTED_UNITS:
        return "unitMeasure must be one of: g, kg, ml, l, each"
    if payload.get("priceUnit", payload["unitMeasure"]) not in SUPPORTED_UNITS:
        return "priceUnit must be one of: g, kg, ml, l, each"
    if UNIT_FAMILY[payload["unitMeasure"]] != UNIT_FAMILY[payload.get("priceUnit", payload["unitMeasure"])]:
        return "Recipe unit and price unit must belong to the same measurement family."
    if isinstance(payload["marketPrice"], bool) or not isinstance(payload["marketPrice"], (int, float)):
        return "marketPrice must be a non-negative number"
    if not math.isfinite(payload["marketPrice"]) or payload["marketPrice"] < 0:
        return "marketPrice must be a non-negative number"
    price_source = payload.get("priceSource", "")
    price_date = payload.get("priceDate", "")
    if price_source is None:
        price_source = ""
    if price_date is None:
        price_date = ""
    if not isinstance(price_source, str) or not isinstance(price_date, str):
        return "priceSource and priceDate must be text."
    if bool(price_source.strip()) != bool(price_date.strip()):
        return "Enter both a price source and an observation date, or leave both blank to mark the price unverified."
    has_package = payload.get("packagePurchasePrice") not in (None, "") or payload.get("packageSize") not in (None, "")
    if not (price_source.strip() and price_date.strip()) and (payload["marketPrice"] > 0 or has_package):
        return "A price above zero or a package price needs a dated source. Otherwise leave the price at 0 and keep it unverified."
    if price_date.strip():
        try:
            datetime.strptime(price_date, "%Y-%m-%d")
        except ValueError:
            return "priceDate must be a valid date."
    if payload.get("priceType", "market_reference") not in ("market_reference", "verified_product"):
        return "priceType must be market_reference or verified_product"
    record_scope = payload.get("recordScope", "generic")
    if record_scope not in ("generic", "product_specific"):
        return "recordScope must be generic or product_specific."
    if payload.get("priceType") == "verified_product" and not str(payload.get("productSpecification", "")).strip():
        return "A verified product price requires a product/brand specification"
    if payload.get("priceType") == "verified_product" and record_scope != "product_specific":
        return "A verified product price must belong to a product-specific ingredient record."
    if record_scope == "generic" and payload.get("productSpecification") and payload.get("referenceAcknowledged") is not True:
        return "Explicitly confirm that this variant-specific market reference is suitable for the generic ingredient."
    for field in ("productSpecification", "priceLocation", "priceReportType"):
        if payload.get(field) is not None and not isinstance(payload[field], str):
            return f"{field} must be text."
    if not (payload.get("priceLocation") or "NCR").strip():
        return "A price observation location is required."
    if not (payload.get("priceReportType") or "Manual observation").strip():
        return "A price report type is required."
    try:
        normalize_package_price(payload)
    except ValueError as error:
        return str(error)
    return None


def validate_estimate(payload):
    required_fields = ("base_price", "yield_loss", "complexity", "target_servings", "portion_weight")
    missing_field = next((field for field in required_fields if field not in payload), None)
    if missing_field:
        return f"{missing_field} is required"

    for field in required_fields:
        value = payload[field]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return f"{field} must be a number"

    if payload["base_price"] < 0:
        return "base_price must be non-negative"
    if not 0 <= payload["yield_loss"] < 1:
        return "yield_loss must be from 0 to less than 1"
    if payload["complexity"] < 1 or payload["complexity"] > 5:
        return "complexity must be from 1 to 5"
    if payload["target_servings"] <= 0:
        return "target_servings must be greater than 0"
    if payload["portion_weight"] <= 0:
        return "portion_weight must be greater than 0"
    return None


def estimate_value(payload, snake_case, camel_case, default, converter):
    value = payload.get(snake_case, payload.get(camel_case, default))
    try:
        converted = converter(value)
        if isinstance(converted, float) and not math.isfinite(converted):
            return converter(default)
        return converted
    except (TypeError, ValueError):
        return converter(default)


@app.teardown_appcontext
def teardown_database(error):
    close_db(error)


@app.get("/")
def index():
    return render_template("index.html", active_page="home", standalone_ingredients=False)


@app.get("/ingredients")
def ingredients_page():
    return send_from_directory("public", "ingredients.html")


@app.get("/food")
def food():
    return render_template("food.html", active_page="builder")


@app.get("/predictor")
def cost_predictor():
    return render_template("predictor.html", active_page="predictor")


@app.get("/saves")
def saves():
    return render_template("saves.html", active_page="saves")


@app.get("/favorites")
def favorites_legacy_redirect():
    return redirect("/saves", code=301)


@app.get("/prices")
def price_monitoring():
    return render_template("prices.html", active_page="prices")


def _parse_da_daily_index_text(text):
    date_match = re.search(r"\((?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday),\s*([A-Za-z]+\s+\d{1,2},\s+\d{4})\)", text, re.I)
    if not date_match:
        date_match = re.search(r"DAILY PRICE INDEX.*?([A-Za-z]+\s+\d{1,2},\s+\d{4})", text, re.I | re.S)
    if not date_match:
        raise ValueError("Could not identify the date in the DA Daily Price Index.")
    report_date = datetime.strptime(date_match.group(1), "%B %d, %Y").date().isoformat()

    # The Daily Price Index specifies price units in its notes: commodities/kg,
    # eggs/piece, and cooking oil/liter. Only conservative exact-family matches
    # are imported; brand/specification variants remain for manual review.
    lines = [" ".join(line.split()) for line in text.splitlines() if line.strip()]
    rows, pending = [], []
    value_pattern = re.compile(r"^(.*?)\s+([\d,]+\.\d{2}|n/a)$", re.I)
    for line in lines:
        if re.match(r"^(page \d+ of \d+|department of agriculture|daily price index|national capital region|prevailing retail price|commodity|note\(s?\)|covered market)", line, re.I):
            continue
        match = value_pattern.match(line)
        if not match:
            pending.append(line)
            continue
        description = " ".join(pending + [match.group(1)]).strip()
        pending = []
        price_text = match.group(2)
        if price_text.lower() == "n/a":
            continue
        price = float(price_text.replace(",", ""))
        norm = description.casefold()
        canonical = None
        if "belly (liempo), local" in norm: canonical = "Liempo"
        elif "picnic shoulder (kasim), local" in norm: canonical = "Pork Kasim"
        elif "rump (tapadera), local" in norm: canonical = "Beef Rump"
        elif "roundscad (galunggong), local" in norm: canonical = "Galunggong"
        # The DA daily index lists branded and unbranded poultry separately.
        # Only the unbranded observation maps to KusinA.I.'s generic ingredient.
        elif "whole chicken" in norm and "unbranded" in norm: canonical = "Whole Chicken"
        elif "breast (pecho)" in norm and "unbranded" in norm: canonical = "Chicken Breast"
        elif "bangus" in norm and "medium" in norm: canonical = "Bangus"
        elif "tilapia" in norm: canonical = "Tilapia"
        elif "tomato" in norm: canonical = "Kamatis"
        elif "garlic, native/local" in norm: canonical = "Bawang"
        elif "red onion, local" in norm: canonical = "Sibuyas"
        elif "bitter gourd (ampalaya)" in norm: canonical = "Ampalaya"
        elif "eggplant" in norm: canonical = "Talong"
        elif "carrots, local" in norm: canonical = "Carrot"
        elif "squash" in norm: canonical = "Kalabasa"
        elif "white potato, local" in norm: canonical = "Patatas"
        # Keep the generic rice record aligned to the local commercial-rice row,
        # not the imported commercial-rice row appearing earlier in the report.
        elif "regular milled" in norm and "local commercial rice" in norm: canonical = "Regular Milled Rice"
        elif "chicken egg (white, medium)" in norm: canonical = "Chicken Egg (White, Medium)"
        is_oil = "cooking oil" in norm
        oil_variant = None
        for variant in ("Palm Olein", "Coconut", "Minola", "Spring", "Palm"):
            if is_oil and f"cooking oil ({variant.casefold()})" in norm:
                oil_variant = variant
                canonical = f"Cooking Oil ({variant})"
                break
        package = _extract_package_size(description) if is_oil else None
        unit = "each" if "chicken egg" in norm else "l" if is_oil else "kg"
        rows.append({"source_name": description, "specification": description, "price": price, "unit": unit,
                     "canonical_name": canonical, "needs_review": bool(is_oil and not oil_variant),
                     "manual_matchable": bool(is_oil and not oil_variant), "package_size": package[0] if package else None,
                     "package_unit": package[1] if package else None,
                     "note": "Unmatched oil variant needs manual confirmation." if is_oil and not oil_variant
                     else None if canonical else "No safe automatic ingredient match; review manually."})
    if not rows:
        raise ValueError("No priced commodity rows could be extracted from the DA Daily Price Index.")
    return {"report_date": report_date, "report_type": "Daily Price Index", "location": "NCR",
            "source": "DA-AMAS Daily Price Index", "rows": rows}


def _extract_package_size(description):
    match = re.search(
        r"(\d+(?:\.\d+)?)\s*(millilit(?:er|re)s?|ml|lit(?:er|re)s?|l|kg|g|pcs?|each)\s*/\s*(?:bottle|pack|package|pc|piece)",
        description, re.I,
    )
    if not match:
        return None
    amount = float(match.group(1))
    unit_text = match.group(2).casefold()
    if unit_text in ("milliliter", "milliliters", "millilitre", "millilitres", "ml"):
        unit = "ml"
    elif unit_text in ("liter", "liters", "litre", "litres", "l"):
        unit = "l"
    elif unit_text == "kg":
        unit = "kg"
    elif unit_text == "g":
        unit = "g"
    else:
        unit = "each"
    return amount, unit


def _parse_da_price_pdf(file_bytes):
    try:
        from pypdf import PdfReader
    except ImportError as error:
        raise ValueError("PDF import requires pypdf. Run: python -m pip install -r requirements.txt") from error
    reader = PdfReader(io.BytesIO(file_bytes))
    text = "\n".join(page.extract_text() or "" for page in reader.pages)
    if "DAILY PRICE INDEX" in text.upper():
        return _parse_da_daily_index_text(text)
    period_match = re.search(r"For the period of ([A-Za-z]+ \d{1,2})\s*[-–]\s*([A-Za-z]+ \d{1,2}),\s*(\d{4})", text, re.I)
    if not period_match:
        raise ValueError("Could not identify the DA report period. Please use an official DA price-monitoring PDF with a readable reporting period.")
    start_text, end_text, year = period_match.groups()
    report_date = datetime.strptime(f"{end_text} {year}", "%B %d %Y").date().isoformat()
    rows=[]
    line_pattern = re.compile(r"^(.*?)\s+(kg|pc|pcs|ml|l)\s+([\d,]+\.\d{2}|-)\s*$", re.I)
    for raw in text.splitlines():
        line=" ".join(raw.split())
        match=line_pattern.match(line)
        if not match:
            continue
        description, unit, price_text=match.groups()
        full_description = description
        if price_text == "-":
            continue
        price=float(price_text.replace(",", ""))
        unit=unit.lower()
        if unit == "pcs": unit="each"
        if unit == "pc": unit="each"
        if unit == "l": unit="l"
        spec=""
        canonical=None
        norm=description.lower()
        # Conservative exact-family matching. Ambiguous variants remain review-only.
        if "pork belly (liempo), local" in norm: canonical="Liempo"
        elif "pork picnic shoulder (kasim), local" in norm: canonical="Pork Kasim"
        elif "whole chicken, local" in norm: canonical="Whole Chicken"
        elif norm.startswith("beef rump, local"): canonical="Beef Rump"
        elif norm.startswith("galunggong, local"): canonical="Galunggong"
        elif norm.startswith("tilapia"): canonical="Tilapia"
        elif norm.startswith("tomato"): canonical="Kamatis"
        elif norm.startswith("garlic, native/local"): canonical="Bawang"
        elif norm.startswith("eggplant"): canonical="Talong"
        elif norm.startswith("carrots, local"): canonical="Carrot"
        elif norm.startswith("ampalaya"): canonical="Ampalaya"
        elif norm.startswith("squash"): canonical="Kalabasa"
        elif norm.startswith("white potato, local"): canonical="Patatas"
        elif norm.startswith("regular milled"): canonical="Regular Milled Rice"
        elif norm.startswith("chicken egg (white, medium)"): canonical="Chicken Egg (White, Medium)"
        is_oil = "cooking oil" in norm
        package = _extract_package_size(description) if is_oil else None
        oil_variant = None
        for variant in ("Palm Olein", "Coconut", "Minola", "Spring", "Palm"):
            if is_oil and f"cooking oil ({variant.casefold()})" in norm:
                oil_variant = variant
                canonical = f"Cooking Oil ({variant})"
                break
        # An exact, known DA oil variety maps to its own record. If the PDF lists
        # a bottle price, the importer normalizes it to PHP/Liter. Unknown oil
        # varieties stay manual-review-only and cannot overwrite generic oil.
        if is_oil:
            unit = "l"
        if "  " in description: description, spec = description.split("  ",1)
        rows.append({"source_name":description,"specification":spec or (full_description if is_oil else ""),"price":price,"unit":unit,
                     "canonical_name":canonical,"needs_review":bool(is_oil and not oil_variant),
                     "manual_matchable":bool(is_oil and not oil_variant),"package_size":package[0] if package else None,
                     "package_unit":package[1] if package else None,
                     "note":"Unknown oil variant requires manual review." if is_oil and not oil_variant
                     else "Named oil bottle price will be normalized to PHP/Liter." if is_oil and package else None})
    if not rows:
        raise ValueError("No priced commodity rows could be extracted from this PDF.")
    return {"report_date":report_date,"report_type":"Weekly Average Retail Price","location":"NCR","source":"DA-AMAS Bantay Presyo Monitoring","rows":rows}


@app.post("/api/prices/import/preview")
def preview_price_import():
    uploaded=request.files.get("file")
    if not uploaded or not uploaded.filename.lower().endswith(".pdf"):
        return jsonify({"error":"Upload an official DA price-monitoring PDF."}),400
    data=uploaded.read(MAX_PRICE_PDF_BYTES+1)
    if len(data)>MAX_PRICE_PDF_BYTES:
        return jsonify({"error":"PDF is too large. Maximum file size is 10 MB."}),413
    try:
        parsed=_parse_da_price_pdf(data)
    except Exception as error:
        return jsonify({"error":str(error)}),400
    ingredients=get_db().execute("SELECT id,name,unit_measure,price_unit FROM ingredients WHERE is_active=1").fetchall()
    lookup={row["name"].strip().casefold():dict(row) for row in ingredients}
    manual_oil_target=lookup.get("cooking oil")
    for item in parsed["rows"]:
        found=lookup.get((item["canonical_name"] or "").casefold())
        item["ingredient_id"] = found["id"] if found else None
        item["matched_name"] = found["name"] if found else None

        if not found and not item.get("manual_matchable"):
            item["needs_review"] = True
            item["note"] = "No matching ingredient was found in KusinA.I. This record must be reviewed before import."

        if item.get("manual_matchable"):
            item["manual_target_id"]=manual_oil_target["id"] if manual_oil_target else None
            item["manual_target_name"]=manual_oil_target["name"] if manual_oil_target else None
        if item["unit"] not in SUPPORTED_UNITS:
            item["needs_review"]=True
            item["note"]="Unsupported unit; review manually."
        if found and UNIT_FAMILY.get(found["unit_measure"]) != UNIT_FAMILY.get(item["unit"]):
            item["needs_review"]=True
            item["note"]="Price unit is incompatible with this ingredient's recipe unit. Verify before importing."
    parsed["filename"]=uploaded.filename
    return jsonify(parsed)


@app.post("/api/prices/import")
def commit_price_import():
    payload = request.get_json(silent=True)

    if (
        not isinstance(payload, dict)
        or not isinstance(payload.get("rows"), list)
        or not payload["rows"]
    ):
        return jsonify({
            "error": "Select at least one reviewed price record to import."
        }), 400

    report_date = payload.get("report_date")
    report_type = payload.get(
        "report_type",
        "Weekly Average Retail Price"
    )
    source = payload.get(
        "source",
        "DA-AMAS Bantay Presyo Monitoring"
    )
    location = payload.get("location", "NCR")

    try:
        datetime.strptime(report_date, "%Y-%m-%d")
    except (TypeError, ValueError):
        return jsonify({
            "error": "A valid report date is required."
        }), 400

    if not all(
        isinstance(value, str) and value.strip()
        for value in (report_type, source, location)
    ):
        return jsonify({
            "error": "The report type, source, and location must be provided."
        }), 400

    manual_oil_rows = [
        row
        for row in payload["rows"]
        if isinstance(row, dict) and row.get("manual_match") is True
    ]

    if len(manual_oil_rows) > 1:
        return jsonify({
            "error": (
                "Import one oil variant at a time so the active reference "
                "is unambiguous."
            )
        }), 400

    database = get_db()

    cursor = database.execute(
        "INSERT INTO price_import_batches "
        "(filename,source,report_type,report_date,location,records_found) "
        "VALUES(?,?,?,?,?,?)",
        (
            payload.get("filename", "DA price report.pdf"),
            source,
            report_type,
            report_date,
            location,
            len(payload["rows"]),
        ),
    )

    batch_id = cursor.lastrowid
    imported = 0

    for item in payload["rows"]:
        if (
            not isinstance(item, dict)
            or not isinstance(item.get("ingredient_id"), int)
        ):
            continue

        is_manual_oil_match = item.get("manual_match") is True

        if is_manual_oil_match:
            if (
                not item.get("manual_matchable")
                or item.get("canonical_name") is not None
                or "cooking oil" not in str(
                    item.get("source_name", "")
                ).casefold()
                or item.get("reference_acknowledged") is not True
            ):
                database.rollback()
                return jsonify({
                    "error": (
                        "A variant-specific oil reference requires "
                        "explicit confirmation and a recognized DA oil row."
                    )
                }), 400

        elif item.get("needs_review"):
            database.execute(
                "INSERT INTO quarantine_records ("
                "source_type, source_filename, source, report_type, report_date, "
                "location, ingredient_id, ingredient_name, raw_data, "
                "validation_status, quarantine_reason, validation_errors"
                ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    "DA price monitoring",
                    payload.get(
                        "filename",
                        "DA price report.pdf"
                    ),
                    source,
                    report_type,
                    report_date,
                    location,
                    item.get("ingredient_id"),
                    item.get("matched_name")
                    or item.get("source_name"),
                    json.dumps(item, ensure_ascii=False),
                    "quarantined",
                    item.get("note")
                    or "Record requires manual review.",
                    item.get("note"),
                ),
            )
            continue

        price = item.get("price")
        ingredient_id = item["ingredient_id"]

        ingredient = database.execute(
            "SELECT id, name, unit_measure, price_unit, market_price, "
            "price_status, price_source, price_date, record_scope, is_active "
            "FROM ingredients WHERE id = ?",
            (ingredient_id,),
        ).fetchone()

        if not ingredient or not ingredient["is_active"]:
            database.rollback()
            return jsonify({
                "error": f"Active ingredient record {ingredient_id} was not found."
            }), 404

        package_size = item.get("package_size")
        package_unit = item.get("package_unit")
        package_price = (
            price
            if is_manual_oil_match
            else item.get("package_purchase_price")
        )
        unit = item.get("unit")

        if is_manual_oil_match:
            if (
                ingredient["name"].casefold() != "cooking oil"
                or ingredient["record_scope"] != "generic"
            ):
                database.rollback()
                return jsonify({
                    "error": (
                        "The approved oil mapping must target the existing "
                        "generic Cooking Oil record."
                    )
                }), 400

            if (
                not is_number(price)
                or price < 0
                or not is_number(package_size)
                or package_unit not in SUPPORTED_UNITS
            ):
                database.rollback()
                return jsonify({
                    "error": (
                        "The oil reference needs a valid package price, "
                        "size, and unit."
                    )
                }), 400

            unit = item.get("unit", "l")

            try:
                package_metadata = normalize_package_price({
                    "marketPrice": price,
                    "priceUnit": unit,
                    "unitMeasure": ingredient["unit_measure"],
                    "packagePurchasePrice": package_price,
                    "packageSize": package_size,
                    "packageUnit": package_unit,
                })
            except ValueError as error:
                database.rollback()
                return jsonify({"error": str(error)}), 400

            normalized_price = package_metadata[0]
            specification = (
                item.get("specification")
                or item.get("source_name", "")
            ).strip()
            price_type = "market_reference"
            reference_confirmed = 1

        else:
            if (
                not is_number(price)
                or price < 0
                or unit not in SUPPORTED_UNITS
                or (
                    item.get("canonical_name") or ""
                ).casefold() != ingredient["name"].casefold()
                or UNIT_FAMILY.get(ingredient["unit_measure"])
                != UNIT_FAMILY.get(unit)
            ):
                continue

            if package_size is not None or package_unit is not None:
                if (
                    not is_number(package_size)
                    or package_unit not in SUPPORTED_UNITS
                ):
                    continue

                try:
                    package_metadata = normalize_package_price({
                        "marketPrice": price,
                        "priceUnit": unit,
                        "unitMeasure": ingredient["unit_measure"],
                        "packagePurchasePrice": price,
                        "packageSize": package_size,
                        "packageUnit": package_unit,
                    })
                except ValueError:
                    continue

                normalized_price = package_metadata[0]
            else:
                normalized_price = price
                package_metadata = (
                    price,
                    None,
                    None,
                    None,
                )

            specification = item.get("specification") or None
            price_type = "market_reference"
            reference_confirmed = 0

        duplicate = database.execute(
            "SELECT 1 FROM ingredient_price_history "
            "WHERE ingredient_id=? AND report_date=? "
            "AND report_type=? AND source=? "
            "AND COALESCE(specification,'')="
            "COALESCE(?,'') LIMIT 1",
            (
                ingredient_id,
                report_date,
                report_type,
                source,
                specification,
            ),
        ).fetchone()

        if duplicate:
            continue

        database.execute(
            "INSERT INTO ingredient_price_history "
            "(ingredient_id,ingredient_name,specification,price,price_unit,"
            "report_type,report_date,source,location,price_type,"
            "package_size,package_unit,package_purchase_price,"
            "import_batch_id,market_reference_confirmed) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                ingredient_id,
                ingredient["name"],
                specification,
                normalized_price,
                unit,
                report_type,
                report_date,
                source,
                location,
                price_type,
                package_metadata[1],
                package_metadata[2],
                package_metadata[3],
                batch_id,
                reference_confirmed,
            ),
        )

        if should_update_current_price(
            report_date,
            ingredient["price_date"],
        ):
            database.execute(
                "UPDATE ingredients SET "
                "market_price=?,price_unit=?,price_source=?,price_date=?,"
                "price_status='documented',price_type=?,"
                "product_specification=?,package_size=?,package_unit=?,"
                "package_purchase_price=?,price_location=?,"
                "price_report_type=?,market_reference_confirmed=?,"
                "updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (
                    normalized_price,
                    unit,
                    source,
                    report_date,
                    price_type,
                    specification,
                    package_metadata[1],
                    package_metadata[2],
                    package_metadata[3],
                    location,
                    report_type,
                    reference_confirmed,
                    ingredient_id,
                ),
            )

            # Recalculate the integrity hash after the current price changes.
            updated_row = database.execute(
                "SELECT id, name, category, unit_measure, price_unit, "
                "market_price, price_source, price_date, price_status, "
                "price_type, record_scope, product_specification, "
                "package_size, package_unit, package_purchase_price, "
                "price_location, price_report_type, "
                "market_reference_confirmed, yield_source, yield_loss, "
                "complexity, complexity_reason "
                "FROM ingredients WHERE id = ?",
                (ingredient_id,),
            ).fetchone()

            database.execute(
                "UPDATE ingredients SET integrity_hash=? WHERE id=?",
                (
                    calculate_integrity_hash(updated_row),
                    ingredient_id,
                ),
            )

        imported += 1

    database.execute(
        "UPDATE price_import_batches SET records_imported=? WHERE id=?",
        (imported, batch_id),
    )

    database.commit()

    return jsonify({
        "batch_id": batch_id,
        "records_imported": imported,
        "records_skipped": len(payload["rows"]) - imported,
    }), 201


class _DALinkParser(HTMLParser):
    def __init__(self):
        super().__init__(); self.links=[]; self.href=None; self.parts=[]
    def handle_starttag(self,tag,attrs):
        if tag.lower()=="a":
            self.href=dict(attrs).get("href"); self.parts=[]
    def handle_data(self,data):
        if self.href is not None: self.parts.append(data)
    def handle_endtag(self,tag):
        if tag.lower()=="a" and self.href is not None:
            self.links.append((self.href," ".join(" ".join(self.parts).split())))
            self.href=None; self.parts=[]


@app.get("/api/prices/check-da")
def check_da_reports():
    page_url="https://www.da.gov.ph/price-monitoring/"
    try:
        req=urllib.request.Request(page_url,headers={"User-Agent":"KusinAI-PriceMonitor/1.0"})
        with urllib.request.urlopen(req,timeout=20) as response:
            html=response.read(5_000_000).decode("utf-8",errors="replace")
        parser=_DALinkParser(); parser.feed(html)
        candidates=[]
        for href,label in parser.links:
            if ".pdf" not in href.lower(): continue
            full=href if href.startswith("http") else urllib.parse.urljoin(page_url,href)
            text=f"{label} {full}"
            daily=bool(re.search(r"DPI|daily.price.index",text,re.I))
            date_match=re.search(r"([A-Z][a-z]+\s+\d{1,2},\s+\d{4})",label)
            weekly=bool(re.search(r"weekly|average",text,re.I))
            if daily or weekly:
                candidates.append({"label":label,"url":full,"kind":"daily" if daily else "weekly","date_text":date_match.group(1) if date_match else label})
        daily_items=[x for x in candidates if x["kind"]=="daily"]
        weekly_items=[x for x in candidates if x["kind"]=="weekly"]
        def sort_key(item):
            try: return datetime.strptime(item["date_text"],"%B %d, %Y")
            except ValueError: return datetime.min
        daily_items.sort(key=sort_key,reverse=True); weekly_items.sort(key=sort_key,reverse=True)
        return jsonify({"source":page_url,"checked_at":datetime.now().isoformat(timespec="seconds"),
            "latest_daily":daily_items[0] if daily_items else None,"latest_weekly":weekly_items[0] if weekly_items else None,
            "note":"This checks the DA listing page for new report links. It does not silently import prices; review and import the PDF preview."})
    except Exception as error:
        return jsonify({"error":f"Could not check the DA website: {error}"}),502


def _latest_da_daily_report():
    """Return the newest dated Daily Price Index PDF linked by the official DA page."""
    page_url = "https://www.da.gov.ph/price-monitoring/"
    req = urllib.request.Request(
        page_url,
        headers={"User-Agent": "KusinAI-PriceMonitor/2.0 (+local educational research project)"},
    )
    with urllib.request.urlopen(req, timeout=25, context=ssl.create_default_context(cafile=certifi.where())) as response:
        html = response.read(5_000_000).decode("utf-8", errors="replace")

    parser = _DALinkParser()
    parser.feed(html)
    candidates = []
    for href, label in parser.links:
        if ".pdf" not in href.lower():
            continue
        full_url = urllib.parse.urljoin(page_url, href)
        parsed_url = urllib.parse.urlparse(full_url)
        host = (parsed_url.hostname or "").lower()
        if parsed_url.scheme != "https" or not (host == "da.gov.ph" or host.endswith(".da.gov.ph")):
            continue
        context = f"{label} {full_url}"
        if not re.search(r"DPI|daily[\s_-]*price[\s_-]*index", context, re.I):
            continue
        date_match = re.search(r"([A-Z][a-z]+\s+\d{1,2},\s+\d{4})", label)
        if not date_match:
            date_match = re.search(r"([A-Z][a-z]+-\d{1,2}-\d{4})", full_url)
        if not date_match:
            continue
        date_text = date_match.group(1)
        parsed_date = None
        for fmt in ("%B %d, %Y", "%B-%d-%Y"):
            try:
                parsed_date = datetime.strptime(date_text, fmt).date()
                break
            except ValueError:
                pass
        if parsed_date:
            candidates.append({"label": label or date_text, "url": full_url,
                               "date_text": date_text, "report_date": parsed_date.isoformat()})

    if not candidates:
        raise ValueError("The official DA page did not expose a dated Daily Price Index PDF link.")
    candidates.sort(key=lambda item: item["report_date"], reverse=True)
    return candidates[0], page_url


def _auto_sync_da_prices_impl():
    """Fetch and safely import the newest official DA Daily Price Index automatically.

    Only existing ingredients with exact parser-supported canonical names and
    compatible measurement families are imported. Ambiguous rows are not guessed.
    """
    try:
        report, listing_url = _latest_da_daily_report()
        database = get_db()
        latest_import = database.execute(
            "SELECT report_date FROM price_import_batches "
            "WHERE source='DA-AMAS Daily Price Index' AND report_type='Daily Price Index' "
            "ORDER BY report_date DESC, id DESC LIMIT 1"
        ).fetchone()
        if latest_import and report["report_date"] <= latest_import["report_date"]:
            return jsonify({
                "status": "already_current",
                "report_date": report["report_date"],
                "report_label": report["label"],
                "report_url": report["url"],
                "records_imported": 0,
                "records_skipped": 0,
                "note": "KusinA.I. already has this DA report date or a newer Daily Price Index.",
                "checked_at": datetime.now(ZoneInfo("Asia/Manila")).isoformat(timespec="seconds"),
                "listing_url": listing_url,
            })

        pdf_request = urllib.request.Request(
            report["url"],
            headers={"User-Agent": "KusinAI-PriceMonitor/2.0 (+local educational research project)"},
        )
        with urllib.request.urlopen(
            pdf_request, timeout=35, context=ssl.create_default_context(cafile=certifi.where())
        ) as response:
            pdf_bytes = response.read(MAX_PRICE_PDF_BYTES + 1)
        if len(pdf_bytes) > MAX_PRICE_PDF_BYTES:
            raise ValueError("The latest DA PDF exceeds the 10 MB safety limit.")
        if not pdf_bytes.startswith(b"%PDF"):
            raise ValueError("The latest DA report link did not return a valid PDF file.")

        parsed = _parse_da_price_pdf(pdf_bytes)
        if parsed["report_type"] != "Daily Price Index" or parsed["report_date"] != report["report_date"]:
            raise ValueError("The downloaded DA report date or report type did not match the official listing.")

        ingredient_rows = database.execute(
            "SELECT id, name, unit_measure FROM ingredients WHERE is_active=1"
        ).fetchall()
        lookup = {row["name"].strip().casefold(): row for row in ingredient_rows}
        import_rows = []
        unmatched_count = 0
        for item in parsed["rows"]:
            canonical = item.get("canonical_name")
            found = lookup.get(str(canonical or "").strip().casefold())
            safe_match = (
                found is not None
                and not item.get("needs_review")
                and item.get("unit") in SUPPORTED_UNITS
                and UNIT_FAMILY.get(found["unit_measure"]) == UNIT_FAMILY.get(item.get("unit"))
            )
            if not safe_match:
                unmatched_count += 1
                continue
            import_rows.append({
                **item,
                "ingredient_id": int(found["id"]),
                "matched_name": found["name"],
            })

        if not import_rows:
            return jsonify({
                "status": "no_safe_matches",
                "report_date": parsed["report_date"],
                "report_label": report["label"],
                "report_url": report["url"],
                "records_imported": 0,
                "records_skipped": len(parsed["rows"]),
                "note": "The DA report was fetched, but no rows passed KusinA.I.'s exact ingredient and unit checks. No prices were changed.",
                "checked_at": datetime.now(ZoneInfo("Asia/Manila")).isoformat(timespec="seconds"),
            })

        payload = {
            "report_date": parsed["report_date"],
            "report_type": parsed["report_type"],
            "source": parsed["source"],
            "location": parsed["location"],
            "filename": Path(urllib.parse.urlparse(report["url"]).path).name or "DA-Daily-Price-Index.pdf",
            "rows": import_rows,
        }
        # Reuse the same validated importer as the reviewed manual workflow.
        with app.test_request_context("/api/prices/import", method="POST", json=payload):
            commit_result = commit_price_import()
        if isinstance(commit_result, tuple):
            response_obj, status_code = commit_result
        else:
            response_obj, status_code = commit_result, 200
        commit_data = response_obj.get_json(silent=True) if hasattr(response_obj, "get_json") else None
        if status_code >= 400 or not isinstance(commit_data, dict):
            raise ValueError((commit_data or {}).get("error", "KusinA.I. could not import the fetched DA prices."))

        return jsonify({
            "status": "updated",
            "report_date": parsed["report_date"],
            "report_label": report["label"],
            "report_url": report["url"],
            "records_imported": commit_data.get("records_imported", 0),
            "records_skipped": unmatched_count + commit_data.get("records_skipped", 0),
            "records_found": len(parsed["rows"]),
            "note": "The newest DA Daily Price Index was fetched automatically. Only exact existing ingredient matches with compatible units were imported; unmatched rows were left unchanged.",
            "checked_at": datetime.now(ZoneInfo("Asia/Manila")).isoformat(timespec="seconds"),
        }), 200
    except (urllib.error.URLError, TimeoutError, ssl.SSLError) as error:
        return jsonify({"error": f"Could not reach the official DA website right now. Existing prices were kept. Details: {error}"}), 502
    except Exception as error:
        app.logger.exception("Automatic DA price sync failed")
        return jsonify({"error": f"Automatic DA price sync failed. Existing prices were kept. {error}"}), 502


@app.post("/api/prices/auto-sync")
def auto_sync_da_prices():
    """Serialize scheduled and user-triggered checks to prevent duplicate imports."""
    if not DA_AUTO_SYNC_LOCK.acquire(blocking=False):
        return jsonify({
            "status": "sync_in_progress",
            "records_imported": 0,
            "note": "A DA price check is already running. Please wait for that check to finish.",
        }), 202
    try:
        return _auto_sync_da_prices_impl()
    finally:
        DA_AUTO_SYNC_LOCK.release()


@app.get("/api/prices/history")
def price_history():
    rows=get_db().execute("SELECT id,ingredient_id,ingredient_name,specification,price,price_unit,report_type,report_date,source,location,imported_at,price_type,package_size,package_unit,package_purchase_price,market_reference_confirmed FROM ingredient_price_history ORDER BY report_date DESC,id DESC LIMIT 500").fetchall()
    return jsonify([dict(row) for row in rows])


@app.get("/api/prices/batches")
def price_import_batches():
    rows=get_db().execute("SELECT * FROM price_import_batches ORDER BY id DESC LIMIT 30").fetchall()
    return jsonify([dict(row) for row in rows])


@app.get("/api/ingredients")
def list_ingredients():
    rows = get_db().execute(
        "SELECT id, name, category, unit_measure, price_unit, market_price, price_source, price_date, "
        "price_status, price_type, record_scope, product_specification, package_size, package_unit, "
        "package_purchase_price, price_location, price_report_type, market_reference_confirmed, "
        "yield_source, yield_loss, complexity, complexity_reason, integrity_hash, "
        "created_at, updated_at "
        "FROM ingredients WHERE is_active=1 ORDER BY created_at DESC, id DESC"
    ).fetchall()

    return jsonify([ingredient_from_row(row) for row in rows])


@app.get("/api/ingredients/integrity")
def ingredients_integrity():
    database = get_db()
    rows = database.execute(
        "SELECT id, name, integrity_hash FROM ingredients WHERE is_active=1 ORDER BY name COLLATE NOCASE"
    ).fetchall()
    results = [verify_ingredient_integrity(database, row["id"]) for row in rows]
    verified = sum(1 for item in results if item and item["integrityStatus"] == "verified")
    mismatched = sum(1 for item in results if item and item["integrityStatus"] == "mismatch")
    missing = sum(1 for item in results if item and item["integrityStatus"] not in ("verified", "mismatch"))
    return jsonify({
        "algorithm": "SHA-256",
        "total": len(results),
        "verified": verified,
        "mismatched": mismatched,
        "missing": missing,
        "status": "verified" if not mismatched and not missing else "review_required",
        "records": results,
    })


@app.get("/api/recipes")
def list_recipes():
    rows = get_db().execute(
        "SELECT id, recipe_name, servings, created_at, updated_at FROM recipes ORDER BY recipe_name COLLATE NOCASE"
    ).fetchall()
    return jsonify([dict(row) for row in rows])


@app.get("/api/recipes/<int:recipe_id>")
def get_recipe(recipe_id):
    database = get_db()
    recipe = database.execute(
        "SELECT id, recipe_name, servings, created_at, updated_at FROM recipes WHERE id = ?",
        (recipe_id,),
    ).fetchone()
    if recipe is None:
        return jsonify({"error": "Recipe not found."}), 404
    ingredients = database.execute(
        "SELECT ingredient_id, quantity, quantity_unit FROM recipe_ingredients "
        "WHERE recipe_id = ? ORDER BY id",
        (recipe_id,),
    ).fetchall()
    return jsonify({**dict(recipe), "ingredients": [dict(row) for row in ingredients]})


def validate_recipe(payload):
    if not isinstance(payload, dict):
        return "Request body must be a JSON object."

    name = payload.get("recipe_name")
    servings = payload.get("servings")
    items = payload.get("ingredients")

    if not isinstance(name, str) or not name.strip() or len(name.strip()) > 200:
        return "Recipe name must contain 1 to 200 characters."

    if (
        isinstance(servings, bool)
        or not isinstance(servings, int)
        or servings < 1
    ):
        return "Servings must be a positive whole number."

    if not isinstance(items, list) or not items:
        return "Add at least one ingredient to the recipe."

    seen = set()
    database = get_db()

    for item in items:
        if not isinstance(item, dict):
            return "Each recipe ingredient must be an object."

        ingredient_id = item.get("ingredient_id")
        quantity = item.get("quantity")
        unit = item.get("unit", item.get("quantity_unit"))

        if (
            isinstance(ingredient_id, bool)
            or not isinstance(ingredient_id, int)
        ):
            return "Each recipe ingredient must reference a valid ingredient."

        if ingredient_id in seen:
            return (
                "A recipe can include each ingredient once; "
                "combine duplicate quantities."
            )

        seen.add(ingredient_id)

        if not is_number(quantity) or quantity <= 0:
            return "Recipe quantities must be greater than zero."

        if unit not in SUPPORTED_UNITS:
            return "Recipe ingredient units must be g, kg, ml, l, or each."

        ingredient = database.execute(
            "SELECT name, unit_measure, market_price, price_status, "
            "price_source, price_date "
            "FROM ingredients WHERE id = ? AND is_active=1",
            (ingredient_id,),
        ).fetchone()

        if ingredient is None:
            return f"Ingredient record {ingredient_id} was not found in the active Ingredient Library."

        if (
            ingredient["price_status"] != "documented"
            or not is_number(ingredient["market_price"])
            or ingredient["market_price"] <= 0
            or not ingredient["price_source"]
            or not ingredient["price_date"]
        ):
            return (
                f'{ingredient["name"]} does not have a documented usable price. '
                "Add a dated market reference or verified product/package price "
                "before using it in a recipe."
            )

        try:
            convert_quantity(
                float(quantity),
                unit,
                ingredient["unit_measure"],
            )
        except ValueError as error:
            return str(error)

    return None


def write_recipe_ingredients(database, recipe_id, items):
    database.execute("DELETE FROM recipe_ingredients WHERE recipe_id = ?", (recipe_id,))
    database.executemany(
        "INSERT INTO recipe_ingredients (recipe_id, ingredient_id, quantity, quantity_unit) "
        "VALUES (?, ?, ?, ?)",
        [
            (recipe_id, item["ingredient_id"], float(item["quantity"]),
             item.get("unit", item.get("quantity_unit")))
            for item in items
        ],
    )


@app.post("/api/recipes")
def create_recipe():
    payload = request.get_json(silent=True)
    validation_error = validate_recipe(payload)
    if validation_error:
        return jsonify({"error": validation_error}), 400
    database = get_db()
    try:
        cursor = database.execute(
            "INSERT INTO recipes (recipe_name, servings) VALUES (?, ?)",
            (payload["recipe_name"].strip(), payload["servings"]),
        )
        write_recipe_ingredients(database, cursor.lastrowid, payload["ingredients"])
        database.commit()
    except sqlite3.IntegrityError as error:
        database.rollback()
        return jsonify({"error": str(error)}), 409
    return get_recipe(cursor.lastrowid), 201


@app.put("/api/recipes/<int:recipe_id>")
def update_recipe(recipe_id):
    payload = request.get_json(silent=True)
    validation_error = validate_recipe(payload)
    if validation_error:
        return jsonify({"error": validation_error}), 400
    database = get_db()
    try:
        cursor = database.execute(
            "UPDATE recipes SET recipe_name = ?, servings = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            (payload["recipe_name"].strip(), payload["servings"], recipe_id),
        )
        if cursor.rowcount == 0:
            database.rollback()
            return jsonify({"error": "Recipe not found."}), 404
        write_recipe_ingredients(database, recipe_id, payload["ingredients"])
        database.commit()
    except sqlite3.IntegrityError as error:
        database.rollback()
        return jsonify({"error": str(error)}), 409
    return get_recipe(recipe_id)


@app.get("/api/recipes/save")
def list_saved_recipes():
    rows = get_db().execute(
        "SELECT id, recipe_name, servings, total_cost, cost_per_serving, created_at "
        "FROM saved_recipes ORDER BY id DESC"
    ).fetchall()
    return jsonify([dict(row) for row in rows])


@app.get("/api/recipes/save/<int:recipe_id>/items")
def get_saved_recipe_items(recipe_id):
    rows = get_db().execute(
        "SELECT ingredient_name, quantity, quantity_unit, as_purchased_quantity, price_unit, unit_price, "
        "line_cost, yield_loss_percent, price_source, price_date, yield_source, price_type, "
        "product_specification, package_size, package_unit, package_purchase_price, price_location, "
        "price_report_type, market_reference_confirmed "
        "FROM saved_recipe_items WHERE recipe_id = ? ORDER BY id", (recipe_id,)
    ).fetchall()
    return jsonify([dict(row) for row in rows])


@app.post("/api/recipes/save")
def save_recipe():
    payload = request.get_json(silent=True)

    if not isinstance(payload, dict):
        return jsonify({
            "error": "Request body must be a JSON object"
        }), 400

    recipe_name = payload.get(
        "recipe_name",
        payload.get("recipeName")
    )

    if (
        not isinstance(recipe_name, str)
        or not recipe_name.strip()
    ):
        return jsonify({
            "error": "recipe_name is required"
        }), 400

    servings = payload.get("servings")

    if (
        isinstance(servings, bool)
        or not isinstance(servings, int)
        or servings <= 0
    ):
        return jsonify({
            "error": "servings must be a positive integer"
        }), 400

    items = payload.get("items", [])
    calculated = None

    if items:
        try:
            calculated = calculate_recipe_cost(
                items,
                servings
            )

            total_cost = calculated[
                "total_estimated_cost_php"
            ]

            cost_per_serving = calculated[
                "cost_per_serving_php"
            ]

        except ValueError as error:
            return jsonify({
                "error": str(error)
            }), 400

    else:
        total_cost = payload.get(
            "total_cost",
            payload.get("totalCost")
        )

        cost_per_serving = payload.get(
            "cost_per_serving",
            payload.get("costPerServing")
        )

        for field, value in (
            ("total_cost", total_cost),
            ("cost_per_serving", cost_per_serving),
        ):
            if not is_number(value) or value < 0:
                return jsonify({
                    "error": (
                        f"{field} must be a non-negative number"
                    )
                }), 400

    database = get_db()

    try:
        cursor = database.execute(
            "INSERT INTO saved_recipes "
            "(recipe_name, servings, total_cost, cost_per_serving) "
            "VALUES (?, ?, ?, ?)",
            (
                recipe_name.strip(),
                servings,
                total_cost,
                cost_per_serving,
            ),
        )

        recipe_id = cursor.lastrowid

        if calculated:
            for line in calculated["ingredient_breakdown"]:
                database.execute(
                    "INSERT INTO saved_recipe_items "
                    "(recipe_id, ingredient_id, ingredient_name, "
                    "quantity, quantity_unit, as_purchased_quantity, "
                    "price_unit, unit_price, line_cost, "
                    "yield_loss_percent, price_source, price_date, "
                    "yield_source, price_type, product_specification, "
                    "package_size, package_unit, package_purchase_price, "
                    "price_location, price_report_type, "
                    "market_reference_confirmed) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        recipe_id,
                        line["ingredient_id"],
                        line["name"],
                        line["recipe_quantity"],
                        line["recipe_unit"],
                        line["as_purchased_quantity"],
                        line["price_unit"],
                        line["market_price_per_unit"],
                        line["line_cost_php"],
                        line["yield_loss_percent"],
                        line["price_source"],
                        line["price_date"],
                        line["yield_source"],
                        line["price_type"],
                        line["product_specification"],
                        line["package_size"],
                        line["package_unit"],
                        line["package_purchase_price"],
                        line["price_location"],
                        line["price_report_type"],
                        int(line["market_reference_confirmed"]),
                    ),
                )

        database.commit()

    except sqlite3.IntegrityError as error:
        database.rollback()
        return jsonify({
            "error": str(error)
        }), 409

    row = database.execute(
        "SELECT id, recipe_name, servings, total_cost, "
        "cost_per_serving, created_at "
        "FROM saved_recipes WHERE id = ?",
        (recipe_id,),
    ).fetchone()

    return jsonify(dict(row)), 201


@app.get("/api/recipes/save/<int:recipe_id>/download")
def download_saved_recipe(recipe_id):
    database = get_db()
    recipe = database.execute(
        "SELECT id, recipe_name, servings, total_cost, cost_per_serving, created_at "
        "FROM saved_recipes WHERE id=?", (recipe_id,)
    ).fetchone()
    if recipe is None:
        return jsonify({"error": "Saved recipe not found."}), 404
    items = database.execute(
        "SELECT ingredient_name, quantity, quantity_unit, as_purchased_quantity, price_unit, "
        "unit_price, line_cost, yield_loss_percent, price_source, price_date, yield_source, "
        "price_type, product_specification, package_size, package_unit, package_purchase_price, "
        "price_location, price_report_type, market_reference_confirmed "
        "FROM saved_recipe_items WHERE recipe_id=? ORDER BY id", (recipe_id,)
    ).fetchall()
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow((
        "recipe_name", "servings", "batch_total_php", "cost_per_serving_php", "saved_at",
        "ingredient_name", "quantity_per_serving", "quantity_per_serving_unit", "batch_quantity",
        "batch_quantity_unit", "as_purchased_quantity", "price_unit", "unit_price_php",
        "line_cost_php", "yield_loss_percent", "price_source", "price_date", "price_location",
        "price_report_type", "product_specification", "package_size", "package_unit",
        "package_purchase_price_php", "yield_source", "market_reference_confirmed"
    ))
    if not items:
        writer.writerow((recipe["recipe_name"], recipe["servings"], recipe["total_cost"],
                         recipe["cost_per_serving"], recipe["created_at"]))
    else:
        for item in items:
            writer.writerow((
                recipe["recipe_name"], recipe["servings"], recipe["total_cost"],
                recipe["cost_per_serving"], recipe["created_at"], item["ingredient_name"],
                round(item["quantity"] / recipe["servings"], 4), item["quantity_unit"],
                item["quantity"], item["quantity_unit"], item["as_purchased_quantity"],
                item["price_unit"], item["unit_price"], item["line_cost"],
                item["yield_loss_percent"], item["price_source"], item["price_date"],
                item["price_location"], item["price_report_type"], item["product_specification"],
                item["package_size"], item["package_unit"], item["package_purchase_price"],
                item["yield_source"], item["market_reference_confirmed"],
            ))
    safe_name = re.sub(r"[^A-Za-z0-9_-]+", "_", recipe["recipe_name"]).strip("_") or f"recipe_{recipe_id}"
    return Response(
        output.getvalue(),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{safe_name}_cost_breakdown.csv"'}
    )


@app.get("/api/recipes/export")
def export_recipes():
    database = get_db()
    recipes = database.execute(
        "SELECT id, recipe_name, servings, total_cost, cost_per_serving, created_at "
        "FROM saved_recipes ORDER BY id"
    ).fetchall()
    csv_output = io.StringIO(newline="")
    writer = csv.writer(csv_output)
    writer.writerow((
        "recipe_name", "servings", "batch_total_php", "cost_per_serving_php", "saved_at",
        "ingredient_name", "quantity_per_serving", "quantity_per_serving_unit", "batch_quantity",
        "batch_quantity_unit", "as_purchased_quantity", "price_unit", "unit_price_php",
        "line_cost_php", "yield_loss_percent", "price_source", "price_date", "price_location",
        "price_report_type", "product_specification", "package_size", "package_unit",
        "package_purchase_price_php", "yield_source", "market_reference_confirmed"
    ))
    for recipe in recipes:
        items = database.execute(
            "SELECT ingredient_name, quantity, quantity_unit, as_purchased_quantity, price_unit, "
            "unit_price, line_cost, yield_loss_percent, price_source, price_date, yield_source, "
            "price_type, product_specification, package_size, package_unit, package_purchase_price, "
            "price_location, price_report_type, market_reference_confirmed "
            "FROM saved_recipe_items WHERE recipe_id=? ORDER BY id", (recipe["id"],)
        ).fetchall()
        if not items:
            writer.writerow((recipe["recipe_name"], recipe["servings"], recipe["total_cost"],
                             recipe["cost_per_serving"], recipe["created_at"]))
            continue
        for item in items:
            writer.writerow((
                recipe["recipe_name"], recipe["servings"], recipe["total_cost"],
                recipe["cost_per_serving"], recipe["created_at"], item["ingredient_name"],
                round(item["quantity"] / recipe["servings"], 4), item["quantity_unit"],
                item["quantity"], item["quantity_unit"], item["as_purchased_quantity"],
                item["price_unit"], item["unit_price"], item["line_cost"],
                item["yield_loss_percent"], item["price_source"], item["price_date"],
                item["price_location"], item["price_report_type"], item["product_specification"],
                item["package_size"], item["package_unit"], item["package_purchase_price"],
                item["yield_source"], item["market_reference_confirmed"],
            ))
    return Response(
        csv_output.getvalue(),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=saved_recipes_cost_breakdown.csv"},
    )

@app.post("/api/ingredients")
def create_ingredient():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({"error": "Request body must be a JSON object"}), 400

    validation_error = validate_ingredient(payload)
    if validation_error:
        return jsonify({"error": validation_error}), 400

    database = get_db()
    archived = database.execute(
        "SELECT id FROM ingredients WHERE lower(name)=lower(?) AND is_active=0 LIMIT 1",
        (payload["name"].strip(),),
    ).fetchone()
    if archived:
        return jsonify({"error": "This ingredient was previously deleted but its price history is archived. Restore its database record instead of adding a duplicate."}), 409
    normalized = normalize_package_price(payload)
    record_scope = payload.get("recordScope", "generic")
    price_type = payload.get("priceType", "market_reference")
    price_location = (payload.get("priceLocation") or "NCR").strip()
    price_report_type = (payload.get("priceReportType") or "Manual observation").strip()
    reference_confirmed = int(payload.get("referenceAcknowledged") is True)
    price_source = (payload.get("priceSource") or "").strip() or None
    price_date = (payload.get("priceDate") or "").strip() or None
    price_status = "documented" if price_source and price_date else "unverified"

    try:
        cursor = database.execute(
            "INSERT INTO ingredients (name, category, unit_measure, price_unit, market_price, price_source, "
            "price_date, price_status, price_type, record_scope, product_specification, package_size, "
            "package_unit, package_purchase_price, price_location, price_report_type, "
            "market_reference_confirmed, yield_source) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                payload["name"].strip(),
                payload["category"].strip(),
                payload["unitMeasure"],
                payload.get("priceUnit", payload["unitMeasure"]),
                normalized[0] or 0,
                price_source,
                price_date,
                price_status,
                price_type,
                record_scope,
                payload.get("productSpecification") or None,
                normalized[1],
                normalized[2],
                normalized[3],
                price_location if price_status == "documented" else None,
                price_report_type if price_status == "documented" else None,
                reference_confirmed,
                payload.get("yieldSource"),
            ),
        )
    except sqlite3.IntegrityError as error:
        database.rollback()
        return jsonify({"error": str(error)}), 409

    if price_status == "documented":
        database.execute(
            "INSERT INTO ingredient_price_history "
            "(ingredient_id, ingredient_name, specification, price, price_unit, "
            "report_type, report_date, source, location, price_type, package_size, package_unit, "
            "package_purchase_price, market_reference_confirmed) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                cursor.lastrowid,
                payload["name"].strip(),
                payload.get("productSpecification") or "General market reference",
                normalized[0],
                payload.get("priceUnit", payload["unitMeasure"]),
                price_report_type,
                price_date,
                price_source,
                price_location,
                price_type,
                normalized[1],
                normalized[2],
                normalized[3],
                reference_confirmed,
            ),
        )

    # Get the newly-created ingredient record.
    row = database.execute(
        "SELECT id, name, category, unit_measure, price_unit, market_price, price_source, price_date, "
        "price_status, price_type, record_scope, product_specification, package_size, package_unit, "
        "package_purchase_price, price_location, price_report_type, market_reference_confirmed, "
        "yield_source, yield_loss, complexity, complexity_reason, integrity_hash, "
        "created_at, updated_at "
        "FROM ingredients WHERE id = ?",
        (cursor.lastrowid,),
    ).fetchone()

    # Generate and store the SHA-256 integrity hash.
    integrity_hash = calculate_integrity_hash(row)

    database.execute(
        "UPDATE ingredients SET integrity_hash = ? WHERE id = ?",
        (integrity_hash, cursor.lastrowid),
    )

    database.commit()

    # Get the final record including the newly-saved integrity hash.
    row = database.execute(
        "SELECT id, name, category, unit_measure, price_unit, market_price, price_source, price_date, "
        "price_status, price_type, record_scope, product_specification, package_size, package_unit, "
        "package_purchase_price, price_location, price_report_type, market_reference_confirmed, "
        "yield_source, yield_loss, complexity, complexity_reason, integrity_hash, "
        "created_at, updated_at "
        "FROM ingredients WHERE id = ?",
        (cursor.lastrowid,),
    ).fetchone()

    return jsonify(ingredient_from_row(row)), 201


def is_number(value):
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value)


def should_update_current_price(report_date, current_price_date):
    """Keep the current price at the newest dated observation."""
    return report_date >= (current_price_date or "0000-00-00")


@app.post("/api/ingredients/serving-parameters")
def save_serving_parameters():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({"error": "Request body must be a JSON object"}), 400

    recipe_name = payload.get("recipeName")
    if not isinstance(recipe_name, str) or not recipe_name.strip():
        return jsonify({"error": "recipeName must be a non-empty string"}), 400
    serving_count = payload.get("servingCount")
    if not is_number(serving_count) or serving_count <= 0:
        return jsonify({"error": "servingCount must be greater than 0"}), 400
    portion = payload.get("targetPortionGrams")
    if portion is not None and (not is_number(portion) or portion <= 0):
        return jsonify({"error": "targetPortionGrams must be greater than 0"}), 400
    waste = payload.get("wasteBufferPercent", 0)
    if not is_number(waste) or waste < 0 or waste >= 100:
        return jsonify({"error": "wasteBufferPercent must be from 0 to less than 100"}), 400

    database = get_db()
    cursor = database.execute(
        "INSERT INTO serving_parameters "
        "(recipe_name, serving_count, target_portion_grams, waste_buffer_percent) "
        "VALUES (?, ?, ?, ?)",
        (recipe_name.strip(), serving_count, portion, waste),
    )
    database.commit()
    row = database.execute(
        "SELECT id, recipe_name, serving_count, target_portion_grams, waste_buffer_percent, created_at "
        "FROM serving_parameters WHERE id = ?",
        (cursor.lastrowid,),
    ).fetchone()
    return jsonify({
        "id": row["id"],
        "recipeName": row["recipe_name"],
        "servingCount": row["serving_count"],
        "targetPortionGrams": row["target_portion_grams"],
        "wasteBufferPercent": row["waste_buffer_percent"],
        "createdAt": row["created_at"],
    }), 201


@app.put("/api/ingredients/<int:ingredient_id>/preparation-attributes")
def save_preparation_attributes(ingredient_id):
    payload = request.get_json(silent=True)

    if not isinstance(payload, dict):
        return jsonify({
            "error": "Request body must be a JSON object"
        }), 400

    complexity = payload.get("complexityScore")
    yield_loss_percent = payload.get("yieldLossPercent")
    complexity_reason = payload.get("complexityReason", "")
    yield_source = payload.get("yieldSource", "")

    if (
        not is_number(complexity)
        or complexity < 1
        or complexity > 5
    ):
        return jsonify({
            "error": "complexityScore must be a number from 1 to 5"
        }), 400

    if (
        not is_number(yield_loss_percent)
        or yield_loss_percent < 0
        or yield_loss_percent >= 100
    ):
        return jsonify({
            "error": (
                "yieldLossPercent must be a number "
                "from 0 to less than 100"
            )
        }), 400

    if (
        not isinstance(complexity_reason, str)
        or not complexity_reason.strip()
        or len(complexity_reason) > 500
    ):
        return jsonify({
            "error": (
                "Add a short explanation for the preparation rating "
                "(maximum 500 characters)."
            )
        }), 400

    if not isinstance(yield_source, str) or len(yield_source) > 500:
        return jsonify({
            "error": (
                "yieldSource must be text no longer than 500 characters."
            )
        }), 400

    if yield_loss_percent > 0 and not yield_source.strip():
        return jsonify({
            "error": (
                "A non-zero yield loss requires a traceable yield data "
                "source. Use 0% until a source is available."
            )
        }), 400

    database = get_db()

    cursor = database.execute(
        "UPDATE ingredients SET "
        "complexity = ?, "
        "complexity_reason = ?, "
        "yield_loss = ?, "
        "yield_source = ?, "
        "updated_at = CURRENT_TIMESTAMP "
        "WHERE id = ? AND is_active=1",
        (
            int(round(complexity)),
            complexity_reason.strip(),
            yield_loss_percent / 100,
            yield_source.strip() or None,
            ingredient_id,
        ),
    )

    if cursor.rowcount == 0:
        database.rollback()
        return jsonify({
            "error": "Ingredient not found"
        }), 404

    updated_row = database.execute(
        "SELECT id, name, category, unit_measure, price_unit, "
        "market_price, price_source, price_date, price_status, "
        "price_type, record_scope, product_specification, "
        "package_size, package_unit, package_purchase_price, "
        "price_location, price_report_type, "
        "market_reference_confirmed, yield_source, yield_loss, "
        "complexity, complexity_reason "
        "FROM ingredients WHERE id = ?",
        (ingredient_id,),
    ).fetchone()

    integrity_hash = calculate_integrity_hash(updated_row)

    database.execute(
        "UPDATE ingredients SET integrity_hash = ? "
        "WHERE id = ?",
        (integrity_hash, ingredient_id),
    )

    database.commit()

    row = database.execute(
        "SELECT id, name, category, unit_measure, price_unit, "
        "market_price, price_source, price_date, price_status, "
        "price_type, record_scope, product_specification, "
        "package_size, package_unit, package_purchase_price, "
        "price_location, price_report_type, "
        "market_reference_confirmed, yield_source, yield_loss, "
        "complexity, complexity_reason, integrity_hash, "
        "created_at, updated_at "
        "FROM ingredients WHERE id = ?",
        (ingredient_id,),
    ).fetchone()

    return jsonify(ingredient_from_row(row))


@app.put("/api/ingredients/<int:ingredient_id>")
def update_ingredient(ingredient_id):
    payload = request.get_json(silent=True)

    if not isinstance(payload, dict):
        return jsonify({
            "error": "Request body must be a JSON object."
        }), 400

    database = get_db()

    existing = database.execute(
        "SELECT name, category, record_scope, unit_measure, price_unit, market_price, "
        "price_source, price_date, price_status, price_type, product_specification, "
        "package_size, package_unit, package_purchase_price, price_location, price_report_type "
        "FROM ingredients WHERE id = ? AND is_active=1",
        (ingredient_id,),
    ).fetchone()

    if existing is None:
        return jsonify({
            "error": "Ingredient not found."
        }), 404

    validated_payload = dict(payload)
    validated_payload["name"] = payload.get("name", existing["name"])
    validated_payload["category"] = payload.get("category", existing["category"])
    validated_payload["recordScope"] = existing["record_scope"]

    validation_error = validate_ingredient(validated_payload)

    if validation_error:
        return jsonify({
            "error": validation_error
        }), 400

    if (
        UNIT_FAMILY[existing["unit_measure"]]
        != UNIT_FAMILY[validated_payload["unitMeasure"]]
    ):
        linked_recipe = database.execute(
            "SELECT 1 FROM recipe_ingredients "
            "WHERE ingredient_id = ? LIMIT 1",
            (ingredient_id,),
        ).fetchone()

        if linked_recipe:
            return jsonify({
                "error": (
                    "This ingredient is used by a saved recipe. "
                    "Its measurement family cannot be changed."
                )
            }), 409

    try:
        normalized = normalize_package_price(validated_payload)
    except ValueError as error:
        return jsonify({
            "error": str(error)
        }), 400

    price_location = (
        validated_payload.get("priceLocation")
        or "NCR"
    ).strip()

    price_report_type = (
        validated_payload.get("priceReportType")
        or "Manual observation"
    ).strip()

    price_type = validated_payload.get(
        "priceType",
        "market_reference"
    )

    product_specification = (
        validated_payload.get("productSpecification")
        or None
    )

    reference_confirmed = int(
        validated_payload.get("referenceAcknowledged") is True
    )

    price_source = (
        validated_payload.get("priceSource")
        or ""
    ).strip() or None

    price_date = (
        validated_payload.get("priceDate")
        or ""
    ).strip() or None

    price_status = (
        "documented"
        if price_source and price_date
        else "unverified"
    )

    try:
        cursor = database.execute(
            "UPDATE ingredients SET "
            "name = ?, category = ?, "
            "market_price = ?, "
            "price_unit = ?, "
            "unit_measure = ?, "
            "price_source = ?, "
            "price_date = ?, "
            "price_status = ?, "
            "price_type = ?, "
            "record_scope = ?, "
            "product_specification = ?, "
            "package_size = ?, "
            "package_unit = ?, "
            "package_purchase_price = ?, "
            "price_location = ?, "
            "price_report_type = ?, "
            "market_reference_confirmed = ?, "
            "updated_at = CURRENT_TIMESTAMP "
            "WHERE id = ?",
            (
                validated_payload["name"].strip(),
                validated_payload["category"].strip(),
                (normalized[0] or 0)
                if price_status == "documented"
                else 0,
                validated_payload["priceUnit"],
                validated_payload["unitMeasure"],
                price_source,
                price_date,
                price_status,
                price_type,
                validated_payload["recordScope"],
                product_specification,
                normalized[1],
                normalized[2],
                normalized[3],
                price_location
                if price_status == "documented"
                else None,
                price_report_type
                if price_status == "documented"
                else None,
                reference_confirmed,
                ingredient_id,
            ),
        )

        if cursor.rowcount == 0:
            database.rollback()
            return jsonify({
                "error": "Ingredient not found."
            }), 404

        price_observation_changed = any((
            float(existing["market_price"] or 0) != float((normalized[0] or 0) if price_status == "documented" else 0),
            (existing["price_unit"] or existing["unit_measure"]) != validated_payload["priceUnit"],
            (existing["price_source"] or None) != price_source,
            (existing["price_date"] or None) != price_date,
            (existing["price_status"] or "unverified") != price_status,
            (existing["price_type"] or "market_reference") != price_type,
            (existing["product_specification"] or None) != product_specification,
            existing["package_size"] != normalized[1],
            (existing["package_unit"] or None) != normalized[2],
            existing["package_purchase_price"] != normalized[3],
            (existing["price_location"] or None) != (price_location if price_status == "documented" else None),
            (existing["price_report_type"] or None) != (price_report_type if price_status == "documented" else None),
        ))
        if price_status == "documented" and price_observation_changed:
            database.execute(
                "INSERT INTO ingredient_price_history "
                "(ingredient_id, ingredient_name, specification, price, "
                "price_unit, report_type, report_date, source, location, "
                "price_type, package_size, package_unit, "
                "package_purchase_price, market_reference_confirmed) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    ingredient_id,
                    validated_payload["name"].strip(),
                    product_specification or "General market reference",
                    normalized[0],
                    validated_payload["priceUnit"],
                    price_report_type,
                    price_date,
                    price_source,
                    price_location,
                    price_type,
                    normalized[1],
                    normalized[2],
                    normalized[3],
                    reference_confirmed,
                ),
            )

        row = database.execute(
            "SELECT id, name, category, unit_measure, price_unit, "
            "market_price, price_source, price_date, price_status, "
            "price_type, record_scope, product_specification, "
            "package_size, package_unit, package_purchase_price, "
            "price_location, price_report_type, "
            "market_reference_confirmed, yield_source, yield_loss, "
            "complexity, complexity_reason "
            "FROM ingredients WHERE id = ?",
            (ingredient_id,),
        ).fetchone()

        integrity_hash = calculate_integrity_hash(row)

        database.execute(
            "UPDATE ingredients SET integrity_hash = ? "
            "WHERE id = ?",
            (integrity_hash, ingredient_id),
        )

        database.commit()

    except sqlite3.IntegrityError as error:
        database.rollback()
        return jsonify({
            "error": str(error)
        }), 409

    row = database.execute(
        "SELECT id, name, category, unit_measure, price_unit, "
        "market_price, price_source, price_date, price_status, "
        "price_type, record_scope, product_specification, "
        "package_size, package_unit, package_purchase_price, "
        "price_location, price_report_type, "
        "market_reference_confirmed, yield_source, yield_loss, "
        "complexity, complexity_reason, integrity_hash, "
        "created_at, updated_at "
        "FROM ingredients WHERE id = ?",
        (ingredient_id,),
    ).fetchone()

    return jsonify(ingredient_from_row(row))


@app.delete("/api/ingredients/<int:ingredient_id>")
def delete_ingredient(ingredient_id):
    database = get_db()
    linked_recipe = database.execute(
        "SELECT 1 FROM recipe_ingredients WHERE ingredient_id=? LIMIT 1", (ingredient_id,)
    ).fetchone()
    if linked_recipe:
        return jsonify({"error": "This ingredient is used by a saved recipe and cannot be removed from the active library."}), 409
    cursor = database.execute(
        "UPDATE ingredients SET is_active=0, updated_at=CURRENT_TIMESTAMP "
        "WHERE id=? AND is_active=1", (ingredient_id,)
    )
    if cursor.rowcount == 0:
        database.rollback()
        return jsonify({"error": "Ingredient not found."}), 404
    database.commit()
    # Historical price rows are intentionally retained for auditability.
    return "", 204

@app.post("/api/estimate")
def estimate_cost():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({"error": "Request body must be a JSON object."}), 400
    try:
        result = calculate_recipe_cost(payload.get("ingredients"), payload.get("servings"))
    except ValueError as error:
        return jsonify({"error": str(error)}), 400
    target_budget = payload.get("target_budget")
    if is_number(target_budget) and target_budget >= 0:
        result["target_budget_php"] = round(float(target_budget), 2)
        result["budget_variance_php"] = round(float(target_budget) - result["total_estimated_cost_php"], 2)
        result["within_budget"] = result["budget_variance_php"] >= 0
    return jsonify(result)


def gemini_key_is_configured():
    key = os.environ.get("GEMINI_API_KEY", "").strip()
    return bool(key) and not key.upper().startswith(("PASTE_", "YOUR_", "REPLACE_"))


@app.get("/api/ai/status")
def gemini_status():
    return jsonify({"configured": gemini_key_is_configured(),
                    "model": os.environ.get("GEMINI_MODEL", "gemini-3.8-flash")})


@app.post("/api/ai/analysis")
@app.post("/api/ai/search")  # Backward compatibility for older page scripts.
def gemini_search():
    """Call Gemini server-side, retry transient failures, and fall back across stable models."""
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({"error": "Request body must be a JSON object."}), 400
    api_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not gemini_key_is_configured():
        return jsonify({"error": "Gemini API key not configured. Open the .env file beside app.py, replace PASTE_YOUR_GEMINI_API_KEY_HERE with your private Google AI Studio key, save, and restart KusinA.I."}), 503
    question = str(payload.get("question", "")).strip()
    if not question:
        return jsonify({"error": "Enter a question first."}), 400
    if len(question) > 5000:
        return jsonify({"error": "Please keep your question under 5,000 characters."}), 400

    # Attach relevant current database records so the assistant can answer system-specific questions.
    database = get_db()
    ingredient_rows = database.execute(
        "SELECT name,category,unit_measure,price_unit,market_price,price_source,price_date,price_status,price_location "
        "FROM ingredients ORDER BY name LIMIT 300"
    ).fetchall()
    recipe_rows = database.execute(
        "SELECT recipe_name,servings FROM recipes ORDER BY updated_at DESC LIMIT 100"
    ).fetchall()
    saved_rows = database.execute(
        "SELECT recipe_name,servings,total_cost,cost_per_serving,created_at "
        "FROM saved_recipes ORDER BY id DESC LIMIT 50"
    ).fetchall()
    history_rows = database.execute(
        "SELECT ingredient_name,price,price_unit,report_date,source,location,specification "
        "FROM ingredient_price_history ORDER BY report_date DESC,id DESC LIMIT 200"
    ).fetchall()
    context = {
        "page": str(payload.get("page", "KusinA.I"))[:120],
        "ingredients": [dict(row) for row in ingredient_rows],
        "recipes": [dict(row) for row in recipe_rows],
        "saved_recipes": [dict(row) for row in saved_rows],
        "price_history": [dict(row) for row in history_rows],
        "calculation": payload.get("calculation") if isinstance(payload.get("calculation"), dict) else None,
    }
    system_instruction = (
        "You are KusinA.I. Analysis, an English-language analytical assistant for a Philippine recipe and food-costing system. "
        "Analyze the supplied ingredient records, dated price history, saved recipe costs, and the user's calculation. "
        "Explain patterns, comparisons, possible cost drivers, data gaps, and practical implications with clear reasoning. "
        "Use only supplied database context for specific prices and saved recipes. Never invent prices, sources, dates, "
        "ingredient variants, densities, piece weights, yield loss, or preparation ratings. Prices are dated references, "
        "not live store quotes. Distinguish NCR DA reference data from local provincial prices. "
        "Mass converts only between g and kg; volume only between ml and l; pieces only to pieces. "
        "Do not convert mass to volume or pieces without verified ingredient-specific data. "
        "Recipe quantities are per serving and batch quantities scale by serving count. "
        "Current cost estimates cover direct ingredient costs only, not labor or overhead. "
        "If information is missing or unverified, state that clearly. Answer clearly and concisely in English."
    )
    configured_model = os.environ.get("GEMINI_MODEL", "gemini-3.8-flash").strip() or "gemini-3.8-flash"
    # Keep the configured model first. These are documented stable text-capable Flash fallbacks.
    model_candidates = [configured_model]
    for fallback in ("gemini-3.7-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite"):
        if fallback not in model_candidates:
            model_candidates.append(fallback)

    body = json.dumps({
        "systemInstruction": {"parts": [{"text": system_instruction}]},
        "contents": [{"role": "user", "parts": [{"text": "SYSTEM DATA (JSON):\n" + json.dumps(context, ensure_ascii=False) + "\n\nUSER QUESTION:\n" + question}]}],
        "generationConfig": {"temperature": 0.3, "maxOutputTokens": 1200},
    }).encode("utf-8")

    last_error_code = None
    last_error_detail = ""
    attempted_models = []
    for model_index, model in enumerate(model_candidates):
        attempted_models.append(model)
        # Retry the preferred model once for temporary overload/quota responses;
        # then move to the next model rather than leaving the user waiting indefinitely.
        attempts_for_model = 2 if model_index == 0 else 1
        for attempt in range(attempts_for_model):
            req = urllib.request.Request(
                f"https://generativelanguage.googleapis.com/v1beta/models/{urllib.parse.quote(model, safe='-')}:generateContent",
                data=body,
                headers={"Content-Type": "application/json", "x-goog-api-key": api_key},
                method="POST",
            )
            try:
                with urllib.request.urlopen(
                    req, timeout=35,
                    context=ssl.create_default_context(cafile=certifi.where())
                ) as response:
                    result = json.loads(response.read().decode("utf-8"))
                answer = "".join(
                    part.get("text", "")
                    for part in result.get("candidates", [{}])[0].get("content", {}).get("parts", [])
                )
                if not answer:
                    return jsonify({"error": "Gemini returned an empty response. Please try again."}), 502
                return jsonify({"answer": answer, "model": model,
                                "fallback_used": model != configured_model})
            except urllib.error.HTTPError as error:
                last_error_code = error.code
                last_error_detail = error.read().decode("utf-8", errors="replace")[:1200]
                if error.code in (503, 429, 404):
                    if attempt + 1 < attempts_for_model:
                        time.sleep(1.5)
                        continue
                    # 503: model overloaded; 429: model quota/rate limit; 404: model unavailable.
                    break
                if error.code in (401, 403):
                    message = "Google rejected this API key. Check the key in your local .env file and confirm the Gemini Developer API is enabled for its Google project."
                else:
                    message = f"Gemini API returned HTTP {error.code}. {last_error_detail}"
                return jsonify({"error": message}), 502
            except (urllib.error.URLError, TimeoutError) as error:
                return jsonify({"error": f"Could not reach Gemini. Check your internet connection and try again. ({error})"}), 502
            except (ValueError, KeyError, IndexError, TypeError) as error:
                return jsonify({"error": f"Could not read Gemini's response: {error}"}), 502

    if last_error_code == 429:
        message = ("Gemini is rate-limiting the available models right now. Please wait a minute and try again. "
                   f"Models tried: {', '.join(attempted_models)}.")
        status_code = 429
    elif last_error_code == 404:
        message = ("Google could not find one or more configured Gemini models. Check GEMINI_MODEL in .env. "
                   f"Models tried: {', '.join(attempted_models)}. Details: {last_error_detail}")
        status_code = 502
    else:
        message = ("Gemini models are temporarily overloaded. KusinA.I retried the primary model and tried its "
                   "backup models, but none accepted the request. Please try again shortly. "
                   f"Models tried: {', '.join(attempted_models)}. Details: {last_error_detail}")
        status_code = 503
    return jsonify({"error": message}), status_code


init_db()


def start_da_price_scheduler():
    """Check the official DA listing in the background while Flask is running."""
    if app.config.get("DA_PRICE_SCHEDULER_STARTED"):
        return
    app.config["DA_PRICE_SCHEDULER_STARTED"] = True

    def scheduler_loop():
        # Let the local server finish starting before the first background request.
        time.sleep(60)
        while True:
            try:
                with app.test_client() as client:
                    response = client.post("/api/prices/auto-sync")
                    app.logger.info(
                        "Scheduled DA price check finished with HTTP %s: %s",
                        response.status_code,
                        response.get_json(silent=True),
                    )
            except Exception:
                app.logger.exception("Scheduled DA price check could not complete")
            time.sleep(6 * 60 * 60)

    worker = threading.Thread(
        target=scheduler_loop,
        name="kusinai-da-price-monitor",
        daemon=True,
    )
    worker.start()


if __name__ == "__main__":
    start_da_price_scheduler()
    app.run(host=os.environ.get("KUSINAI_HOST", "127.0.0.1"), port=int(os.environ.get("KUSINAI_PORT", "5016")))
