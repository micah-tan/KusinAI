# DA reference dataset

`da_daily_price_index_2026-11-13.csv` is a structured copy of 23 explicitly mapped observations from the Philippine Department of Agriculture (DA) Daily Price Index dated 13 November 2026. The report is linked at: https://www.da.gov.ph/wp-content/uploads/2026/11/November-13-2026-DPI-AFC.pdf

The data scope is **NCR**. It is not a quote from a specific retailer and must not be presented as an Antipolo or provincial store price. Most commodity prices are PHP/kg; eggs are PHP/each; oil observations are PHP/liter. Cooking-oil varieties remain separate. Kangkong, repolyo, toyo, suka, and generic cooking oil have no matching observation in this snapshot and are intentionally left unpriced.

For later updates, download the newer official DA PDF, use **Price Monitoring → Preview report**, review every match, and import only the records that are exact and compatible.
