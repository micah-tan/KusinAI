const $ = (selector) => document.querySelector(selector);
const toggle = $('#aiSearchToggle');
const panel = $('#aiAssistant');
const closeButton = $('#aiSearchClose');
const form = $('#aiForm');
const promptInput = $('#aiPrompt');
const output = $('#aiOutput');
const status = $('#aiConnection');

function setOpen(open) {
  if (!panel || !toggle) return;
  panel.hidden = !open;
  toggle.setAttribute('aria-expanded', String(open));
  if (open) promptInput?.focus();
}
toggle?.addEventListener('click', () => setOpen(panel.hidden));
closeButton?.addEventListener('click', () => setOpen(false));

async function ask(question, extraContext = null) {
  const cleanQuestion = String(question || '').trim();
  if (!cleanQuestion || !output) return;
  setOpen(true);
  output.textContent = 'Analyzing your KusinA.I. data…';
  try {
    const response = await fetch('/api/ai/analysis', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({question: cleanQuestion, page: document.title, calculation: extraContext})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'AI request failed.');
    output.textContent = data.answer;
    if (status) { status.textContent = `Connected · ${data.model}${data.fallback_used ? ' (backup)' : ''}`; status.classList.add('is-connected'); }
  } catch (error) {
    output.textContent = `${error.message}\n\nYou can still use the recipe builder, ingredient library, and cost predictor without AI.`;
    if (status) status.textContent = 'Gemini connection unavailable';
  }
}
form?.addEventListener('submit', async (event) => {
  event.preventDefault();
  await ask(promptInput.value);
});
window.KusinAI = {ask};
window.addEventListener('kusinai:ask', (event) => {
  const detail = event.detail || {};
  ask(detail.prompt, detail.context || null);
});

if (status) {
  fetch('/api/ai/status').then(r => r.json()).then(data => {
    status.textContent = data.configured ? `Ready · ${data.model}` : 'Gemini API key not configured';
  }).catch(() => { status.textContent = 'AI status unavailable'; });
}
