async function apiFetch(url, options) {
  let response;
  try {
    response = await fetch(url, options);
  } catch (error) {
    throw new Error(`${url} could not be reached: ${error.message}`);
  }

  const contentType = response.headers.get("content-type") || "";
  if (!contentType.toLowerCase().includes("application/json")) {
    throw new Error(
      `${url} returned HTTP ${response.status} with ${contentType || "no Content-Type"}; expected JSON. ` +
      "Check that KusinA.I. is running from the current project at this address."
    );
  }
  return response;
}

async function apiJson(url, options) {
  const response = await apiFetch(url, options);
  let data;
  try {
    data = await response.json();
  } catch (error) {
    throw new Error(`${url} returned invalid JSON: ${error.message}`);
  }

  if (!response.ok) {
    throw new Error(data.error || `${url} failed with HTTP ${response.status}.`);
  }
  return data;
}
