import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import joblib

# dost, dole
ph_benchmarks = [
    {"item": "Bawang (Whole Garlic)", "yield_loss": 0.12, "complexity": 5, "base_price_ap": 160.0, "base_prep_mins_per_kg": 25.0},
    {"item": "Kamatis (Tomatoes)", "yield_loss": 0.08, "complexity": 2, "base_price_ap": 70.0, "base_prep_mins_per_kg": 7.0},
    {"item": "Sibuyas (Onions)", "yield_loss": 0.10, "complexity": 3, "base_price_ap": 90.0, "base_prep_mins_per_kg": 12.0},
    {"item": "Liempo (Pork Belly)", "yield_loss": 0.15, "complexity": 4, "base_price_ap": 340.0, "base_prep_mins_per_kg": 18.0},
    {"item": "Manok (Whole Chicken)", "yield_loss": 0.25, "complexity": 4, "base_price_ap": 190.0, "base_prep_mins_per_kg": 22.0},
    {"item": "Kangkong (Trimmed)", "yield_loss": 0.30, "complexity": 2, "base_price_ap": 40.0, "base_prep_mins_per_kg": 10.0},
]


HOURLY_LABOR_RATE_PHP = 75.0  

records = []
np.random.seed(42)


for i in range(250):
    base_item = np.random.choice(ph_benchmarks)
    servings = int(np.random.randint(10, 300))
    portion_kg = 0.15  # Portion weight per serving (kg)
    total_batch_kg = servings * portion_kg
    

    ep_price_per_kg = base_item["base_price_ap"] / (1.0 - base_item["yield_loss"])
    direct_ingredient_cost = round(total_batch_kg * ep_price_per_kg, 2)
    
  
    scaling_friction = 1 + (np.log(servings) * 0.15)
    prep_time_minutes = (total_batch_kg * base_item["base_prep_mins_per_kg"] * scaling_friction) / base_item["complexity"]
    labor_overhead_cost_php = round((prep_time_minutes / 60.0) * HOURLY_LABOR_RATE_PHP, 2)
    
    records.append({
        'ingredient_name': base_item["item"],
        'target_servings': servings,
        'complexity': base_item["complexity"],
        'yield_loss': base_item["yield_loss"],
        'batch_weight_kg': round(total_batch_kg, 2),
        'direct_ingredient_cost_php': direct_ingredient_cost,
        'labor_overhead_cost_php': labor_overhead_cost_php
    })


df = pd.DataFrame(records)
df.to_csv('prep_dataset_ph.csv', index=False)
print("Saved prep_dataset_ph.csv successfully!")

# linear regression training
X = df[['target_servings', 'complexity', 'yield_loss', 'batch_weight_kg']]
y = df['labor_overhead_cost_php']

model = LinearRegression()
model.fit(X, y)

# Save trained machine learning binary
joblib.dump(model, 'overhead_model.pkl')
print("Linear Regression model successfully trained and saved as overhead_model.pkl!")
