import { randomUUID } from 'node:crypto';
import express from 'express';

const router = express.Router();
const ingredients = new Map();
const servingParameters = new Map();
const supportedUnits = new Set(['g', 'kg', 'ml', 'l', 'each']);

function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim().length > 0;
}

function isFiniteNumber(value) {
  return typeof value === 'number' && Number.isFinite(value);
}

function validationError(message) {
  const error = new Error(message);
  error.statusCode = 400;
  return error;
}

function validateIngredientInput(body, { partial = false } = {}) {
  const requiredFields = ['name', 'category', 'unitMeasure', 'marketPrice'];
  if (!partial) {
    const missingField = requiredFields.find((field) => body[field] === undefined);
    if (missingField) {
      throw validationError(`${missingField} is required`);
    }
  }

  if (body.name !== undefined && !isNonEmptyString(body.name)) {
    throw validationError('name must be a non-empty string');
  }
  if (body.category !== undefined && !isNonEmptyString(body.category)) {
    throw validationError('category must be a non-empty string');
  }
  if (body.unitMeasure !== undefined && !supportedUnits.has(body.unitMeasure)) {
    throw validationError(`unitMeasure must be one of: ${[...supportedUnits].join(', ')}`);
  }
  if (body.marketPrice !== undefined && (!isFiniteNumber(body.marketPrice) || body.marketPrice < 0)) {
    throw validationError('marketPrice must be a non-negative number');
  }
}

function validatePreparationAttributes(body) {
  if (!isFiniteNumber(body.complexityScore) || body.complexityScore < 1 || body.complexityScore > 5) {
    throw validationError('complexityScore must be a number from 1 to 5');
  }
  if (!isFiniteNumber(body.yieldLossPercent) || body.yieldLossPercent < 0 || body.yieldLossPercent >= 100) {
    throw validationError('yieldLossPercent must be a number from 0 to less than 100');
  }
}

function validateServingParameters(body) {
  if (!isNonEmptyString(body.recipeName)) {
    throw validationError('recipeName must be a non-empty string');
  }
  if (!isFiniteNumber(body.servingCount) || body.servingCount <= 0) {
    throw validationError('servingCount must be greater than 0');
  }
  if (body.targetPortionGrams !== undefined &&
      (!isFiniteNumber(body.targetPortionGrams) || body.targetPortionGrams <= 0)) {
    throw validationError('targetPortionGrams must be greater than 0');
  }
  if (body.wasteBufferPercent !== undefined &&
      (!isFiniteNumber(body.wasteBufferPercent) || body.wasteBufferPercent < 0 || body.wasteBufferPercent >= 100)) {
    throw validationError('wasteBufferPercent must be from 0 to less than 100');
  }
}

function findIngredientOrThrow(id) {
  const ingredient = ingredients.get(id);
  if (!ingredient) {
    const error = new Error('Ingredient not found');
    error.statusCode = 404;
    throw error;
  }
  return ingredient;
}

router.get('/', (request, response) => {
  response.json([...ingredients.values()]);
});

router.post('/', (request, response, next) => {
  try {
    validateIngredientInput(request.body);
    const now = new Date().toISOString();
    const ingredient = {
      id: randomUUID(),
      name: request.body.name.trim(),
      category: request.body.category.trim(),
      unitMeasure: request.body.unitMeasure,
      marketPrice: request.body.marketPrice,
      preparationAttributes: null,
      createdAt: now,
      updatedAt: now
    };
    ingredients.set(ingredient.id, ingredient);
    response.status(201).json(ingredient);
  } catch (error) {
    next(error);
  }
});

router.get('/:id', (request, response, next) => {
  try {
    response.json(findIngredientOrThrow(request.params.id));
  } catch (error) {
    next(error);
  }
});

router.patch('/:id', (request, response, next) => {
  try {
    const ingredient = findIngredientOrThrow(request.params.id);
    validateIngredientInput(request.body, { partial: true });
    const updates = Object.fromEntries(
      ['name', 'category', 'unitMeasure', 'marketPrice']
        .filter((field) => request.body[field] !== undefined)
        .map((field) => [field, field === 'name' || field === 'category'
          ? request.body[field].trim()
          : request.body[field]])
    );
    Object.assign(ingredient, updates, { updatedAt: new Date().toISOString() });
    response.json(ingredient);
  } catch (error) {
    next(error);
  }
});

router.delete('/:id', (request, response, next) => {
  try {
    findIngredientOrThrow(request.params.id);
    ingredients.delete(request.params.id);
    response.status(204).send();
  } catch (error) {
    next(error);
  }
});

router.put('/:id/preparation-attributes', (request, response, next) => {
  try {
    const ingredient = findIngredientOrThrow(request.params.id);
    validatePreparationAttributes(request.body);
    ingredient.preparationAttributes = {
      complexityScore: request.body.complexityScore,
      yieldLossPercent: request.body.yieldLossPercent,
      prepMinutes: request.body.prepMinutes ?? 0,
      updatedAt: new Date().toISOString()
    };
    response.json(ingredient);
  } catch (error) {
    next(error);
  }
});

router.post('/serving-parameters', (request, response, next) => {
  try {
    validateServingParameters(request.body);
    const parameters = {
      id: randomUUID(),
      recipeName: request.body.recipeName.trim(),
      servingCount: request.body.servingCount,
      targetPortionGrams: request.body.targetPortionGrams ?? null,
      wasteBufferPercent: request.body.wasteBufferPercent ?? 0,
      createdAt: new Date().toISOString()
    };
    servingParameters.set(parameters.id, parameters);
    response.status(201).json(parameters);
  } catch (error) {
    next(error);
  }
});

router.use((error, request, response, next) => {
  if (response.headersSent) {
    next(error);
    return;
  }
  response.status(error.statusCode ?? 500).json({ error: error.message ?? 'Internal server error' });
});

export default router;