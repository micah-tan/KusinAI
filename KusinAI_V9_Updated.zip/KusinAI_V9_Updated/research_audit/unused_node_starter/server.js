import { createServer } from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import ingredientsRouter from './routes/ingredients.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDir = path.join(__dirname, '..', 'public');

const port = Number(process.env.PORT ?? 3000);
const app = express();
const ingredientsApiPath = '/api/ingredients';

app.use(express.json());
app.use(express.static(publicDir));

app.get('/health', (request, response) => {
  response.json({ status: 'ok', service: 'food-prep-cost-predictor' });
});

app.use(ingredientsApiPath, ingredientsRouter);

const server = createServer(app);
server.listen(port, () => {
  console.log(`Food prep cost predictor listening on http://localhost:${port}`);
});
