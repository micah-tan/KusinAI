#!/bin/zsh
set -euo pipefail
cd "$(dirname "$0")"

if [[ ! -x ".venv/bin/python" ]]; then
  echo "Creating local Python environment…"
  python3 -m venv .venv
fi
source .venv/bin/activate

if ! python -c 'import flask, dotenv, pypdf, certifi' >/dev/null 2>&1; then
  echo "Installing KusinA.I. requirements…"
  python -m pip install --upgrade pip
  python -m pip install -r requirements.txt
fi

echo "Opening KusinA.I. at http://127.0.0.1:5016"
python app.py
