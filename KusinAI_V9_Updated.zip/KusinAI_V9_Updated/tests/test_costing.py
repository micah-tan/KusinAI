import unittest
from unittest.mock import patch

import app


class FakeRow(dict):
    def __getitem__(self, key):
        return super().__getitem__(key)


class FakeCursor:
    def __init__(self, row):
        self.row = row

    def fetchone(self):
        return self.row


class FakeDB:
    def __init__(self, row):
        self.row = row

    def execute(self, *_args):
        return FakeCursor(self.row)


class CostingTests(unittest.TestCase):
    def setUp(self):
        self.row = FakeRow(
            id=1, name="Pork", unit_measure="kg", price_unit="kg",
            market_price=380.0, price_source="Test source", price_date="2026-11-01",
            yield_source="Test yield source", yield_loss=0.12, complexity=4, complexity_reason="Requires trimming",
        )

    def test_grams_to_kilograms_and_yield_loss(self):
        with patch.object(app, "get_db", return_value=FakeDB(self.row)):
            result = app.calculate_recipe_cost(
                [{"ingredient_id": 1, "quantity": 800, "unit": "g"}], 4
            )
        self.assertEqual(result["direct_ingredient_cost_php"], 345.45)
        self.assertEqual(result["cost_per_serving_php"], 86.36)
        self.assertEqual(result["breakdown_count"], 1)
        self.assertEqual(result["ingredient_breakdown"][0]["yield_loss_percent"], 12.0)
        self.assertEqual(result["ingredient_breakdown"][0]["recipe_quantity_per_serving"], 200.0)
        self.assertEqual(result["ingredient_breakdown"][0]["recipe_quantity"], 800.0)
        self.assertEqual(result["breakdown_count"], len(result["ingredient_breakdown"]))

    def test_volume_and_mass_are_not_converted(self):
        with patch.object(app, "get_db", return_value=FakeDB(self.row)):
            with self.assertRaisesRegex(ValueError, "not interchangeable"):
                app.calculate_recipe_cost(
                    [{"ingredient_id": 1, "quantity": 20, "unit": "ml"}], 4
                )

    def test_condiment_with_unverified_kg_price_cannot_be_costed_as_ml(self):
        self.row.update(name="Cooking Oil", unit_measure="ml", price_unit="kg")
        with patch.object(app, "get_db", return_value=FakeDB(self.row)):
            with self.assertRaisesRegex(ValueError, "not interchangeable"):
                app.calculate_recipe_cost(
                    [{"ingredient_id": 1, "quantity": 30, "unit": "ml"}], 4
                )

    def test_undocumented_yield_loss_is_blocked(self):
        self.row.update(yield_loss=0.12, yield_source=None)
        with patch.object(app, "get_db", return_value=FakeDB(self.row)):
            with self.assertRaisesRegex(ValueError, "undocumented yield-loss"):
                app.calculate_recipe_cost([{"ingredient_id": 1, "quantity": 100, "unit": "g"}], 1)

    def test_variant_specific_da_reference_is_costable_only_on_specific_record(self):
        self.row.update(
            record_scope="product_specific", price_type="market_reference",
            product_specification="Pork Kasim, local fresh or chilled",
            market_reference_confirmed=0, yield_loss=0.0, yield_source=None,
        )
        with patch.object(app, "get_db", return_value=FakeDB(self.row)):
            result = app.calculate_recipe_cost([{"ingredient_id": 1, "quantity": 250, "unit": "g"}], 2)
        self.assertEqual(result["direct_ingredient_cost_php"], 95.0)
        self.assertEqual(result["cost_per_serving_php"], 47.5)
        self.assertEqual(result["ingredient_breakdown"][0]["product_specification"], "Pork Kasim, local fresh or chilled")

    def test_variant_specific_reference_is_blocked_on_generic_record_without_confirmation(self):
        self.row.update(
            record_scope="generic", price_type="market_reference",
            product_specification="Pork Kasim, local fresh or chilled",
            market_reference_confirmed=0, yield_loss=0.0, yield_source=None,
        )
        with patch.object(app, "get_db", return_value=FakeDB(self.row)):
            with self.assertRaisesRegex(ValueError, "needs explicit confirmation"):
                app.calculate_recipe_cost([{"ingredient_id": 1, "quantity": 100, "unit": "g"}], 1)

    def test_unverified_price_is_blocked_even_when_units_match(self):
        self.row.update(name="Toyo", unit_measure="ml", price_unit="ml", price_status="unverified")
        with patch.object(app, "get_db", return_value=FakeDB(self.row)):
            with self.assertRaisesRegex(ValueError, "no documented usable price"):
                app.calculate_recipe_cost([{"ingredient_id": 1, "quantity": 30, "unit": "ml"}], 4)

    def test_package_price_normalizes_to_selected_unit(self):
        result = app.normalize_package_price({
            "marketPrice": 0, "priceUnit": "ml", "unitMeasure": "ml",
            "packagePurchasePrice": 80, "packageSize": 1000, "packageUnit": "ml"
        })
        self.assertEqual(result[0], 0.08)
        self.assertEqual(result[1:], (1000.0, "ml", 80.0))

    def test_mass_volume_package_mismatch_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "same measurement family"):
            app.normalize_package_price({
                "marketPrice": 0, "priceUnit": "kg", "unitMeasure": "kg",
                "packagePurchasePrice": 80, "packageSize": 1000, "packageUnit": "ml"
            })

    def test_older_report_does_not_replace_newer_current_price(self):
        self.assertFalse(app.should_update_current_price("2026-11-01", "2026-11-13"))
        self.assertTrue(app.should_update_current_price("2026-11-13", "2026-11-01"))
        self.assertTrue(app.should_update_current_price("2026-11-01", None))

    def test_each_quantity_is_supported(self):
        self.row.update(unit_measure="each", price_unit="each", market_price=12.0, yield_loss=0.0)
        with patch.object(app, "get_db", return_value=FakeDB(self.row)):
            result = app.calculate_recipe_cost(
                [{"ingredient_id": 1, "quantity": 3, "unit": "each"}], 3
            )
        self.assertEqual(result["direct_ingredient_cost_php"], 36.0)
        self.assertEqual(result["cost_per_serving_php"], 12.0)


class DailyPriceIndexParserTests(unittest.TestCase):
    def test_extracts_supported_daily_index_commodities(self):
        sample = """Department of Agriculture
DAILY PRICE INDEX
National Capital Region (NCR)
(Friday, November 13, 2026)
COMMODITY SPECIFICATION PREVAILING RETAIL PRICE PER UNIT (P/UNIT)
PORK
Belly (Liempo), Local Fresh or Chilled 368.19
Picnic Shoulder (Kasim), Local Fresh or Chilled 310.55
LOWLAND VEGETABLES
Tomato Ripe, 15-18 pcs/kg 127.49
SPICES
Garlic, Native/Local Whole, covered with outer skin 385.00
EGG
Chicken Egg (White, Medium) 56-60 grams/pc 8.21
OTHER BASIC COMMODITIES
Cooking Oil (Palm) 1 Liter/bottle 103.47
Note(s):
Price per Unit: Agri-fishery commodities except egg: Peso per Kilogram
"""
        result = app._parse_da_daily_index_text(sample)
        self.assertEqual(result["report_date"], "2026-11-13")
        self.assertEqual(result["report_type"], "Daily Price Index")
        mapped = {row["canonical_name"]: row for row in result["rows"] if row["canonical_name"]}
        self.assertEqual(mapped["Liempo"]["price"], 368.19)
        self.assertEqual(mapped["Pork Kasim"]["unit"], "kg")
        self.assertEqual(mapped["Kamatis"]["price"], 127.49)
        self.assertEqual(mapped["Chicken Egg (White, Medium)"]["unit"], "each")
        self.assertEqual(mapped["Cooking Oil (Palm)"]["price"], 103.47)
        self.assertEqual(mapped["Cooking Oil (Palm)"]["unit"], "l")
        oil = next(row for row in result["rows"] if "Cooking Oil" in row["source_name"])
        self.assertEqual(oil["unit"], "l")
        self.assertEqual(oil["canonical_name"], "Cooking Oil (Palm)")
        self.assertFalse(oil["needs_review"])  # Exact DA oil variants have separate ingredient records.

    def test_daily_index_only_maps_unbranded_poultry_and_local_rice_to_generic_records(self):
        sample = """Department of Agriculture
DAILY PRICE INDEX
National Capital Region (NCR)
(Monday, November 16, 2026)
COMMODITY SPECIFICATION PREVAILING RETAIL PRICE PER UNIT (P/UNIT)
IMPORTED COMMERCIAL RICE
Regular Milled 20-40% bran streak 45.50
LOCAL COMMERCIAL RICE
Regular Milled 20-40% bran streak 45.11
CHICKEN
Breast (Pecho), Bounty Fresh Fresh or Chilled, Branded 226.67
Breast (Pecho), Magnolia Fresh or Chilled, Branded 219.22
Breast (Pecho), Unbranded Fresh or Chilled, Unbranded 216.20
Whole Chicken, Bounty Fresh Fresh or Chilled, Branded 193.33
Whole Chicken, Magnolia Fresh or Chilled, Branded 204.39
Whole Chicken, Unbranded Fresh or Chilled, Unbranded 199.40
Note(s):
Price per Unit: Agri-fishery commodities except egg: Peso per Kilogram
"""
        result = app._parse_da_daily_index_text(sample)
        generic_rows = [row for row in result["rows"] if row["canonical_name"] in {
            "Regular Milled Rice", "Chicken Breast", "Whole Chicken"
        }]
        mapped = {row["canonical_name"]: row for row in generic_rows}
        self.assertEqual(mapped["Regular Milled Rice"]["price"], 45.11)
        self.assertEqual(mapped["Chicken Breast"]["price"], 216.20)
        self.assertEqual(mapped["Whole Chicken"]["price"], 199.40)
        self.assertEqual(len(generic_rows), 3)

    def test_weekly_average_pdf_text_parser(self):
        from unittest.mock import patch
        import sys
        import types

        sample = """Department of Agriculture
Bantay Presyo Monitoring
For the period of October 26 - November 1, 2026
Pork Belly (Liempo), Local kg 359.55
Pork Picnic Shoulder (Kasim), Local kg 303.66
Cooking Oil (Palm) 350 ml/bottle ml 40.28
Cooking Oil (Palm) 1 Liter/bottle L 101.84
"""
        fake_reader = types.SimpleNamespace(pages=[types.SimpleNamespace(extract_text=lambda: sample)])
        fake_module = types.SimpleNamespace(PdfReader=lambda _stream: fake_reader)
        with patch.dict(sys.modules, {"pypdf": fake_module}):
            result = app._parse_da_price_pdf(b"test pdf bytes")
        self.assertEqual(result["report_date"], "2026-11-01")
        self.assertEqual(result["report_type"], "Weekly Average Retail Price")
        liempo = next(row for row in result["rows"] if row["canonical_name"] == "Liempo")
        self.assertEqual(liempo["price"], 359.55)
        bottle = next(row for row in result["rows"] if "350 ml/bottle" in row["source_name"])
        self.assertEqual(bottle["canonical_name"], "Cooking Oil (Palm)")
        self.assertFalse(bottle["needs_review"])
        self.assertEqual((bottle["package_size"], bottle["package_unit"]), (350.0, "ml"))


if __name__ == "__main__":
    unittest.main()
