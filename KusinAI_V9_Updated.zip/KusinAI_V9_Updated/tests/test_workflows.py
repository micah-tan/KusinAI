import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import app


class IsolatedDatabaseTests(unittest.TestCase):
    def setUp(self):
        self.original_database_path = app.DATABASE_PATH
        self.temp_dir = tempfile.TemporaryDirectory()
        app.DATABASE_PATH = Path(self.temp_dir.name) / "kusinai-test.db"
        app.init_db()
        self.client = app.app.test_client()

    def tearDown(self):
        app.DATABASE_PATH = self.original_database_path
        self.temp_dir.cleanup()

    def ingredient_id(self, name):
        response = self.client.get("/api/ingredients")
        self.assertEqual(response.status_code, 200)
        return next(item["id"] for item in response.get_json() if item["name"] == name)

    def test_generic_price_without_package_details_ignores_package_unit_selection(self):
        response = self.client.post("/api/ingredients", json={
            "name": "Browser Test Basil",
            "category": "Browser tests",
            "unitMeasure": "kg",
            "priceUnit": "kg",
            "marketPrice": 35,
            "priceSource": "Test fixture",
            "priceDate": "2026-11-13",
            "priceType": "market_reference",
            "recordScope": "generic",
            "packagePurchasePrice": None,
            "packageSize": None,
            "packageUnit": "kg",
        })
        self.assertEqual(response.status_code, 201, response.get_data(as_text=True))
        ingredient = response.get_json()
        self.assertEqual(ingredient["marketPrice"], 35)
        self.assertIsNone(ingredient["packageSize"])
        self.assertIsNone(ingredient["packageUnit"])

    def test_variant_oil_reference_requires_acknowledgment_and_normalizes_package(self):
        oil_id = self.ingredient_id("Cooking Oil")
        unconfirmed = {
            "report_date": "2026-11-01",
            "report_type": "Weekly Average Retail Price",
            "source": "DA-AMAS Bantay Presyo Monitoring",
            "location": "NCR",
            "filename": "weekly.pdf",
            "rows": [{
                "ingredient_id": oil_id,
                "canonical_name": None,
                "source_name": "Cooking Oil (Palm) 350 ml/bottle",
                "specification": "Cooking Oil (Palm) 350 ml/bottle",
                "price": 40.28,
                "unit": "l",
                "package_size": 350,
                "package_unit": "ml",
                "manual_matchable": True,
                "manual_match": True,
                "reference_acknowledged": False,
            }],
        }
        rejected = self.client.post("/api/prices/import", json=unconfirmed)
        self.assertEqual(rejected.status_code, 400)
        self.assertIn("explicit confirmation", rejected.get_json()["error"])

        unconfirmed["rows"][0]["reference_acknowledged"] = True
        imported = self.client.post("/api/prices/import", json=unconfirmed)
        self.assertEqual(imported.status_code, 201, imported.get_data(as_text=True))
        self.assertEqual(imported.get_json()["records_imported"], 1)

        estimate = self.client.post("/api/estimate", json={
            "servings": 1,
            "ingredients": [{"ingredient_id": oil_id, "quantity": 30, "unit": "ml"}],
        })
        self.assertEqual(estimate.status_code, 200, estimate.get_data(as_text=True))
        line = estimate.get_json()["ingredient_breakdown"][0]
        self.assertAlmostEqual(line["market_price_per_unit"], 40.28 / 0.35)
        self.assertEqual(line["price_unit"], "l")
        self.assertEqual(line["product_specification"], "Cooking Oil (Palm) 350 ml/bottle")
        self.assertEqual(line["package_size"], 350)
        self.assertEqual(line["package_unit"], "ml")
        self.assertEqual(line["package_purchase_price"], 40.28)
        self.assertEqual(line["price_source"], "DA-AMAS Bantay Presyo Monitoring")
        self.assertEqual(line["price_date"], "2026-11-01")
        self.assertEqual(line["price_location"], "NCR")
        self.assertTrue(line["market_reference_confirmed"])
        self.assertEqual(estimate.get_json()["direct_ingredient_cost_php"], 3.45)

        history = self.client.get("/api/prices/history").get_json()
        matching = [row for row in history if row["specification"] == "Cooking Oil (Palm) 350 ml/bottle"]
        self.assertEqual(len(matching), 1)
        self.assertEqual(matching[0]["source"], "DA-AMAS Bantay Presyo Monitoring")

    def test_recipe_definition_crud_and_distinct_page_navigation(self):
        pork_id = self.ingredient_id("Pork Kasim")
        created = self.client.post("/api/recipes", json={
            "recipe_name": "Test adobo",
            "servings": 4,
            "ingredients": [{"ingredient_id": pork_id, "quantity": 500, "unit": "g"}],
        })
        self.assertEqual(created.status_code, 201, created.get_data(as_text=True))
        recipe_id = created.get_json()["id"]
        details = self.client.get(f"/api/recipes/{recipe_id}").get_json()
        self.assertEqual(details["ingredients"][0]["quantity_unit"], "g")

        for path, current_page, other_page in (
            ("/predictor", "Cost Predictor", "Recipe Builder"),
            ("/food", "Recipe Builder", "Cost Predictor"),
            ("/ingredients", "Ingredients", "Saves"),
            ("/saves", "Saves", "Ingredients"),
        ):
            response = self.client.get(path)
            self.assertEqual(response.status_code, 200)
            html = response.get_data(as_text=True)
            self.assertIn(current_page, html)
            self.assertIn(other_page, html)
            self.assertIn("AI Analysis", html)
            self.assertIn("ph-date", html)
            self.assertIn("ph-time", html)

    def test_ingredient_crud_and_integrity_are_database_backed(self):
        created = self.client.post("/api/ingredients", json={
            "name": "CRUD Test Herb", "category": "Vegetables",
            "unitMeasure": "kg", "priceUnit": "kg", "marketPrice": 0,
            "priceSource": "", "priceDate": "", "priceType": "market_reference",
            "recordScope": "generic", "packagePurchasePrice": None,
            "packageSize": None, "packageUnit": "kg",
        })
        self.assertEqual(created.status_code, 201, created.get_data(as_text=True))
        ingredient_id = created.get_json()["id"]

        edit_payload = {
            "name": "CRUD Test Herb", "category": "Pantry",
            "unitMeasure": "kg", "priceUnit": "kg", "marketPrice": 88.5,
            "priceSource": "Test market receipt", "priceDate": "2026-11-16",
            "priceType": "market_reference", "recordScope": "generic",
            "packagePurchasePrice": None, "packageSize": None, "packageUnit": "kg",
            "priceLocation": "Quezon City", "priceReportType": "Manual observation",
            "referenceAcknowledged": False,
        }
        updated = self.client.put(f"/api/ingredients/{ingredient_id}", json=edit_payload)
        self.assertEqual(updated.status_code, 200, updated.get_data(as_text=True))
        self.assertEqual(updated.get_json()["category"], "Pantry")
        self.assertEqual(updated.get_json()["marketPrice"], 88.5)

        # Editing a descriptive field without changing the price should not create another history row.
        edit_payload["category"] = "Vegetables"
        unchanged_price = self.client.put(f"/api/ingredients/{ingredient_id}", json=edit_payload)
        self.assertEqual(unchanged_price.status_code, 200, unchanged_price.get_data(as_text=True))
        history = self.client.get("/api/prices/history").get_json()
        matches = [row for row in history if row["ingredient_id"] == ingredient_id]
        self.assertEqual(len(matches), 1)

        integrity = self.client.get("/api/ingredients/integrity")
        self.assertEqual(integrity.status_code, 200)
        self.assertEqual(integrity.get_json()["status"], "verified")
        self.assertGreaterEqual(integrity.get_json()["verified"], 1)

        deleted = self.client.delete(f"/api/ingredients/{ingredient_id}")
        self.assertEqual(deleted.status_code, 204)
        names = {row["name"] for row in self.client.get("/api/ingredients").get_json()}
        self.assertNotIn("CRUD Test Herb", names)
        history_after_delete = self.client.get("/api/prices/history").get_json()
        self.assertTrue(any(row["ingredient_id"] == ingredient_id for row in history_after_delete))

    def test_ingredient_edit_preserves_and_updates_package_price_details(self):
        created = self.client.post("/api/ingredients", json={
            "name": "Package Edit Test Oil", "category": "Pantry",
            "unitMeasure": "ml", "priceUnit": "ml", "marketPrice": 0,
            "priceSource": "Test grocery receipt", "priceDate": "2026-11-16",
            "priceType": "market_reference", "recordScope": "generic",
            "packagePurchasePrice": 40, "packageSize": 500, "packageUnit": "ml",
            "referenceAcknowledged": False,
        })
        self.assertEqual(created.status_code, 201, created.get_data(as_text=True))
        ingredient_id = created.get_json()["id"]
        self.assertEqual(created.get_json()["marketPrice"], 0.08)

        edited = self.client.put(f"/api/ingredients/{ingredient_id}", json={
            "name": "Package Edit Test Oil", "category": "Pantry",
            "unitMeasure": "ml", "priceUnit": "ml", "marketPrice": 0.08,
            "priceSource": "Updated grocery receipt", "priceDate": "2026-11-17",
            "priceType": "market_reference", "recordScope": "generic",
            "packagePurchasePrice": 45, "packageSize": 500, "packageUnit": "ml",
            "referenceAcknowledged": False,
        })
        self.assertEqual(edited.status_code, 200, edited.get_data(as_text=True))
        self.assertAlmostEqual(edited.get_json()["marketPrice"], 0.09)
        self.assertEqual(edited.get_json()["packagePurchasePrice"], 45)
        self.assertEqual(edited.get_json()["packageSize"], 500)
        self.assertEqual(edited.get_json()["packageUnit"], "ml")

        history = self.client.get("/api/prices/history").get_json()
        matches = [row for row in history if row["ingredient_id"] == ingredient_id]
        self.assertEqual(len(matches), 2)

    def test_saved_recipe_downloads_include_itemized_details(self):
        liempo_id = self.ingredient_id("Liempo")
        saved = self.client.post("/api/recipes/save", json={
            "recipe_name": "Download Test Adobo", "servings": 4,
            "items": [{"ingredient_id": liempo_id, "quantity": 500, "unit": "g"}],
        })
        self.assertEqual(saved.status_code, 201, saved.get_data(as_text=True))
        recipe_id = saved.get_json()["id"]

        individual = self.client.get(f"/api/recipes/save/{recipe_id}/download")
        self.assertEqual(individual.status_code, 200)
        self.assertIn("text/csv", individual.mimetype)
        individual_csv = individual.get_data(as_text=True)
        self.assertIn("Download Test Adobo", individual_csv)
        self.assertIn("Liempo", individual_csv)
        self.assertIn("price_source", individual_csv.splitlines()[0])

        all_recipes = self.client.get("/api/recipes/export")
        self.assertEqual(all_recipes.status_code, 200)
        all_csv = all_recipes.get_data(as_text=True)
        self.assertIn("Download Test Adobo", all_csv)
        self.assertIn("Liempo", all_csv)
        self.assertIn("price_date", all_csv.splitlines()[0])

    def test_automatic_da_sync_fetches_once_and_ignores_duplicate_report(self):
        liempo_id = self.ingredient_id("Liempo")
        report = {
            "label": "November 16, 2026",
            "url": "https://www.da.gov.ph/wp-content/uploads/2026/11/November-16-2026-DPI-AFC.pdf",
            "date_text": "November 16, 2026",
            "report_date": "2026-11-16",
        }
        parsed = {
            "report_date": "2026-11-16", "report_type": "Daily Price Index",
            "source": "DA-AMAS Daily Price Index", "location": "NCR",
            "rows": [{
                "source_name": "Pork belly (liempo), local fresh or chilled",
                "specification": "Pork belly (liempo), local fresh or chilled",
                "price": 379.25, "unit": "kg", "canonical_name": "Liempo",
                "needs_review": False, "manual_matchable": False,
            }],
        }
        fake_response = MagicMock()
        fake_response.__enter__.return_value.read.return_value = b"%PDF-fake-test-payload"
        with patch.object(app, "_latest_da_daily_report", return_value=(report, "https://www.da.gov.ph/price-monitoring/")), \
             patch("app.urllib.request.urlopen", return_value=fake_response) as download_mock, \
             patch.object(app, "_parse_da_price_pdf", return_value=parsed):
            first = self.client.post("/api/prices/auto-sync", json={})
            self.assertEqual(first.status_code, 200, first.get_data(as_text=True))
            self.assertEqual(first.get_json()["status"], "updated")
            self.assertEqual(first.get_json()["records_imported"], 1)
            download_mock.assert_called_once()

        ingredient = next(row for row in self.client.get("/api/ingredients").get_json() if row["id"] == liempo_id)
        self.assertEqual(ingredient["priceDate"], "2026-11-16")
        self.assertEqual(ingredient["marketPrice"], 379.25)

        with patch.object(app, "_latest_da_daily_report", return_value=(report, "https://www.da.gov.ph/price-monitoring/")), \
             patch("app.urllib.request.urlopen") as duplicate_download:
            second = self.client.post("/api/prices/auto-sync", json={})
            self.assertEqual(second.status_code, 200, second.get_data(as_text=True))
            self.assertEqual(second.get_json()["status"], "already_current")
            duplicate_download.assert_not_called()

    def test_new_ingredient_can_be_saved_without_guessing_a_price(self):
        response = self.client.post("/api/ingredients", json={
            "name": "Unpriced Test Herb", "category": "Herbs",
            "unitMeasure": "g", "priceUnit": "g", "marketPrice": 0,
            "priceSource": "", "priceDate": "", "recordScope": "generic",
            "priceType": "market_reference", "packagePurchasePrice": None,
            "packageSize": None, "packageUnit": "g",
        })
        self.assertEqual(response.status_code, 201, response.get_data(as_text=True))
        self.assertEqual(response.get_json()["priceStatus"], "unverified")
        self.assertEqual(response.get_json()["marketPrice"], 0)

    def test_da_snapshot_records_are_ncr_and_specification_scoped(self):
        response = self.client.get("/api/ingredients")
        rows = response.get_json()
        sourced = [x for x in rows if x["priceSource"] == "DA-AMAS Daily Price Index"]
        self.assertEqual(len(sourced), 23)
        self.assertTrue(all(x["recordScope"] == "product_specific" for x in sourced))
        self.assertTrue(all(x["priceDate"] == "2026-11-13" for x in sourced))
        self.assertTrue(all(x["priceLocation"] == "NCR" for x in sourced))
        unpriced = {x["name"]: x for x in rows if x["name"] in {"Kangkong", "Repolyo", "Cooking Oil", "Toyo", "Suka"}}
        self.assertTrue(all(x["priceStatus"] == "unverified" and x["marketPrice"] == 0 for x in unpriced.values()))

    def test_api_routes_return_json_and_predictor_has_an_empty_state(self):
        recipes = self.client.get("/api/recipes")
        self.assertEqual(recipes.status_code, 200)
        self.assertTrue(recipes.is_json)
        self.assertEqual(recipes.get_json(), [])

        ingredients = self.client.get("/api/ingredients")
        self.assertEqual(ingredients.status_code, 200)
        self.assertTrue(ingredients.is_json)

        missing = self.client.get("/api/recipes/999999")
        self.assertEqual(missing.status_code, 404)
        self.assertTrue(missing.is_json)
        self.assertEqual(missing.get_json()["error"], "Recipe not found.")

        unmatched = self.client.get("/api/no-such-endpoint")
        self.assertEqual(unmatched.status_code, 404)
        self.assertTrue(unmatched.is_json)
        self.assertIn("error", unmatched.get_json())

        api_root = self.client.get("/api")
        self.assertEqual(api_root.status_code, 404)
        self.assertTrue(api_root.is_json)

        wrong_method = self.client.put("/api/recipes")
        self.assertEqual(wrong_method.status_code, 405)
        self.assertTrue(wrong_method.is_json)
        self.assertEqual(wrong_method.get_json()["status"], 405)

        with patch.object(app, "get_db", side_effect=RuntimeError("simulated API failure")):
            internal_error = self.client.get("/api/recipes")
        self.assertEqual(internal_error.status_code, 500)
        self.assertTrue(internal_error.is_json)
        self.assertEqual(internal_error.get_json()["status"], 500)

        predictor = self.client.get("/predictor").get_data(as_text=True)
        builder = self.client.get("/food").get_data(as_text=True)
        self.assertIn("No reusable recipe definitions have been saved yet.", predictor)
        self.assertIn('<script src="/api.js"></script>', predictor)
        self.assertIn('<script src="/api.js"></script>', builder)

        prices_page = self.client.get('/prices').get_data(as_text=True)
        self.assertIn('/api/prices/auto-sync', prices_page)
        self.assertIn('Sync latest DA prices', prices_page)
        self.assertNotIn('type="file"', prices_page)
        self.assertNotIn('id="history">', prices_page.split('<section class="panel" id="history-section">', 1)[0])

        helper = self.client.get("/api.js")
        self.assertEqual(helper.status_code, 200)
        self.assertIn("javascript", helper.mimetype)

    def test_legacy_condiment_migration_preserves_price_provenance_and_is_repeatable(self):
        old_path = Path(self.temp_dir.name) / "legacy.db"
        app.DATABASE_PATH = old_path
        connection = sqlite3.connect(old_path)
        connection.execute(
            "CREATE TABLE ingredients ("
            "id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, category TEXT NOT NULL, "
            "unit_measure TEXT NOT NULL, market_price REAL NOT NULL, yield_loss REAL NOT NULL DEFAULT 0, "
            "complexity INTEGER NOT NULL DEFAULT 1, complexity_reason TEXT, price_unit TEXT NOT NULL, "
            "price_source TEXT, price_date TEXT, yield_source TEXT, price_status TEXT, price_type TEXT, "
            "product_specification TEXT, package_size REAL, package_unit TEXT, package_purchase_price REAL, "
            "price_location TEXT, price_report_type TEXT, market_reference_confirmed INTEGER, "
            "created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)"
        )
        connection.execute(
            "INSERT INTO ingredients (id,name,category,unit_measure,market_price,price_unit,price_source,"
            "price_date,price_status,price_type,product_specification,package_size,package_unit,"
            "package_purchase_price,price_location,price_report_type,market_reference_confirmed) "
            "VALUES (42,'Cooking Oil','Pantry','kg',80,'kg','Legacy observation','2026-10-15',"
            "'documented','market_reference','Palm oil package',350,'ml',40,'NCR','Weekly report',1)"
        )
        connection.commit()
        connection.close()

        app.init_db()
        app.init_db()
        connection = sqlite3.connect(old_path)
        oil = connection.execute(
            "SELECT id,unit_measure,market_price,price_unit,price_source,price_date,package_size,package_unit,"
            "package_purchase_price FROM ingredients WHERE id=42"
        ).fetchone()
        history = connection.execute(
            "SELECT ingredient_id,specification,price,price_unit,report_date,source,location,package_size,"
            "package_unit,package_purchase_price FROM ingredient_price_history"
        ).fetchall()
        connection.close()
        self.assertEqual(oil, (42, "ml", 0.0, "ml", None, None, None, None, None))
        legacy_history = [row for row in history if row[0] == 42]
        self.assertEqual(len(legacy_history), 1)
        self.assertEqual(
            legacy_history[0],
            (42, "Palm oil package", 80.0, "kg", "2026-10-15", "Legacy observation", "NCR", 350.0, "ml", 40.0),
        )


if __name__ == "__main__":
    unittest.main()
