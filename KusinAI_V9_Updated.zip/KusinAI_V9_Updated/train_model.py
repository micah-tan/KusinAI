"""Training entry point intentionally disabled pending an empirical, traceable dataset.

The legacy V3 training script generated synthetic rows from hardcoded assumptions.
Those rows are retained under research_audit/legacy_simulated/ for audit only and
must not be represented as measured observations or used for validated predictions.

Before enabling regression training, the research team must supply a documented
observational dataset containing the variables defined in Chapter 2, Section 2.5
and Chapter 3, Section 3.1, plus source, date, region, and measurement provenance.
The model-development and validation protocol must also be documented in the paper.
"""

raise SystemExit(
    "Regression training is disabled. The only supplied training CSV was simulated "
    "from hardcoded assumptions, not verified institutional or time-motion data. "
    "Collect and document empirical observations, then approve the training and "
    "validation protocol before enabling this script. See RESEARCH_TRACEABILITY.md."
)
